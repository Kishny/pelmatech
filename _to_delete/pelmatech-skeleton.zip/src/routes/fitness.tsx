import { createFileRoute } from '@tanstack/react-router'

import fitnessImg from '@/assets/fitness.png'
import { AnimatedHeading } from '@/components/AnimatedHeading'
import { AnimatedText } from '@/components/AnimatedText'
import { Footer } from '@/components/Footer'
import { HealthMetricCard } from '@/components/HealthMetricCard'
import { Header } from '@/components/Header'
import { MaskedImage } from '@/components/MaskedImage'

export const Route = createFileRoute('/fitness')({ component: Fitness })

const FEATURES = [
  'Workout scheduling',
  'Activity tracking',
  'Progress history',
  'Personal fitness goals',
  'Recovery reminders',
]

const METRICS = [
  { value: '4 / 5', label: 'Weekly activity days' },
  { value: '3 planned', label: 'Workouts' },
  { value: '+12%', label: 'Progress (30d)' },
  { value: '2 days', label: 'Recovery reminder' },
]

function Fitness() {
  return (
    <div className="bg-background text-foreground">
      <Header variant="internal" />
      <main className="pt-40 pb-32 px-8 md:px-12">
        <div className="grid grid-cols-1 gap-16 md:grid-cols-2 md:items-center">
          <MaskedImage src={fitnessImg} alt="Pelmatech fitness tracking" className="aspect-[4/3] w-full order-2 md:order-1" />

          <div className="order-1 md:order-2">
            <AnimatedHeading as="h1" className="text-5xl md:text-6xl font-medium leading-[1.05]">
              Movement that fits
              <br />
              the life you actually live.
            </AnimatedHeading>
            <AnimatedText className="mt-6 max-w-md text-base text-muted-foreground leading-relaxed">
              Plan workouts, track activity, and adapt routines as your
              health and schedule change.
            </AnimatedText>
            <div className="mt-8 flex flex-wrap gap-2">
              {FEATURES.map((f) => (
                <span key={f} className="rounded-full border border-border px-4 py-2 text-xs text-muted-foreground">
                  {f}
                </span>
              ))}
            </div>
            <button
              type="button"
              className="mt-10 bg-foreground text-white rounded-full px-6 py-3 text-sm font-medium hover:opacity-90 transition"
            >
              Explore Fitness
            </button>
          </div>
        </div>

        <div className="mt-20 grid grid-cols-2 gap-4 md:grid-cols-4">
          {METRICS.map((m, i) => (
            <HealthMetricCard key={m.label} {...m} delay={i * 0.05} />
          ))}
        </div>
      </main>
      <Footer />
    </div>
  )
}
