import { createFileRoute } from '@tanstack/react-router'

import nutritionImg from '@/assets/nutrition.png'
import { AnimatedHeading } from '@/components/AnimatedHeading'
import { AnimatedText } from '@/components/AnimatedText'
import { Footer } from '@/components/Footer'
import { HealthMetricCard } from '@/components/HealthMetricCard'
import { Header } from '@/components/Header'
import { MaskedImage } from '@/components/MaskedImage'

export const Route = createFileRoute('/nutrition')({ component: Nutrition })

const FEATURES = [
  'Meal logging',
  'Macro tracking',
  'Water intake',
  'Personal targets',
  'Food insights',
  'Professional nutrition support',
]

const TARGETS = [
  { value: '1,840 / 2,100', label: 'Calories (kcal)' },
  { value: '92 / 120 g', label: 'Protein' },
  { value: '210 / 260 g', label: 'Carbohydrates' },
  { value: '58 / 70 g', label: 'Fat' },
  { value: '1.6 / 2.5 L', label: 'Water' },
  { value: '3 logged', label: 'Meals today' },
]

function Nutrition() {
  return (
    <div className="bg-background text-foreground">
      <Header variant="internal" />
      <main className="pt-40 pb-32 px-8 md:px-12">
        <div className="grid grid-cols-1 gap-16 md:grid-cols-2 md:items-center">
          <div>
            <AnimatedHeading as="h1" className="text-5xl md:text-6xl font-medium leading-[1.05]">
              Nutrition without
              <br />
              the guesswork.
            </AnimatedHeading>
            <AnimatedText className="mt-6 max-w-md text-base text-muted-foreground leading-relaxed">
              Understand what you eat, build better habits, and keep your
              nutrition aligned with your goals. No medical diet claims —
              just clearer information.
            </AnimatedText>
            <div className="mt-8 flex flex-wrap gap-2">
              {FEATURES.map((f) => (
                <span key={f} className="rounded-full border border-border px-4 py-2 text-xs text-muted-foreground">
                  {f}
                </span>
              ))}
            </div>
          </div>

          <MaskedImage src={nutritionImg} alt="Pelmatech nutrition tracking" className="aspect-[4/3] w-full" />
        </div>

        <div className="mt-20 grid grid-cols-2 gap-4 md:grid-cols-3">
          {TARGETS.map((t, i) => (
            <HealthMetricCard key={t.label} {...t} delay={i * 0.05} />
          ))}
        </div>
      </main>
      <Footer />
    </div>
  )
}
