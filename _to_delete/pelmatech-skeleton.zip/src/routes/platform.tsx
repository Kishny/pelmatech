import { createFileRoute } from '@tanstack/react-router'
import {
  Activity,
  Bell,
  Calendar,
  Dumbbell,
  Apple,
  FileText,
  LayoutDashboard,
  Pill,
} from 'lucide-react'

import { AnimatedHeading } from '@/components/AnimatedHeading'
import { AnimatedText } from '@/components/AnimatedText'
import { Footer } from '@/components/Footer'
import { Header } from '@/components/Header'

export const Route = createFileRoute('/platform')({ component: Platform })

const CAPABILITIES = [
  { icon: LayoutDashboard, title: 'Dashboard', body: 'A single daily view of your health, appointments, and goals.' },
  { icon: Activity, title: 'Health Tracking', body: 'Activity, heart rate, sleep, weight, hydration, and trends.' },
  { icon: Calendar, title: 'Appointments', body: 'Book, reschedule, and join visits without the back-and-forth.' },
  { icon: Apple, title: 'Nutrition', body: 'Meal logging, macro tracking, and personal targets.' },
  { icon: Dumbbell, title: 'Fitness', body: 'Workout scheduling, activity tracking, and recovery.' },
  { icon: Pill, title: 'Medication', body: 'Schedules, reminders, refill awareness, and history.' },
  { icon: FileText, title: 'Health Records', body: 'A clear, organized record of your care over time.' },
  { icon: Bell, title: 'Notifications', body: 'Reminders that keep you on track without the noise.' },
]

function Platform() {
  return (
    <div className="bg-background text-foreground">
      <Header variant="internal" />
      <main className="pt-40 pb-32 px-8 md:px-12">
        <AnimatedHeading as="h1" className="max-w-2xl text-5xl md:text-6xl font-medium leading-[1.05]">
          Your health,
          <br />
          organized around you.
        </AnimatedHeading>
        <AnimatedText className="mt-6 max-w-xl text-base text-muted-foreground leading-relaxed">
          Every part of the Pelmatech platform, in one place — designed to
          work together instead of living in separate apps.
        </AnimatedText>

        <div className="mt-20 grid grid-cols-1 gap-px overflow-hidden rounded-2xl border border-border bg-border sm:grid-cols-2 lg:grid-cols-4">
          {CAPABILITIES.map((cap, i) => {
            const Icon = cap.icon
            return (
              <div key={cap.title} className="flex flex-col gap-4 bg-background p-8">
                <Icon className="h-6 w-6 text-accent" />
                <AnimatedHeading as="h2" delay={i * 0.05} className="text-lg font-medium">
                  {cap.title}
                </AnimatedHeading>
                <AnimatedText delay={i * 0.05} className="text-sm text-muted-foreground leading-relaxed">
                  {cap.body}
                </AnimatedText>
              </div>
            )
          })}
        </div>
      </main>
      <Footer />
    </div>
  )
}
