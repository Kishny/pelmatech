import { createFileRoute } from '@tanstack/react-router'
import {
  Bell,
  ChevronRight,
  Laptop,
  Lock,
  ShieldCheck,
  Trash2,
  User,
} from 'lucide-react'

import { AnimatedHeading } from '@/components/AnimatedHeading'
import { Footer } from '@/components/Footer'
import { Header } from '@/components/Header'

export const Route = createFileRoute('/settings')({ component: Settings })

const SECTIONS = [
  { icon: User, title: 'Profile', body: 'Name, photo, and personal details.' },
  { icon: Bell, title: 'Notifications', body: 'Appointment, medication, and goal reminders.' },
  { icon: Lock, title: 'Privacy', body: 'Control what is shared and with whom.' },
  { icon: Laptop, title: 'Connected devices', body: 'Manage wearables and linked apps.' },
  { icon: ShieldCheck, title: 'Security', body: 'Password, two-factor authentication, sessions.' },
  { icon: Trash2, title: 'Delete account', body: 'Permanently remove your Pelmatech account.', danger: true },
]

function Settings() {
  return (
    <div className="bg-background text-foreground">
      <Header variant="internal" />
      <main className="pt-40 pb-32 px-8 md:px-12">
        <AnimatedHeading as="h1" className="text-4xl md:text-5xl font-medium leading-[1.05]">
          Settings
        </AnimatedHeading>

        <div className="mt-16 flex flex-col divide-y divide-border border-t border-b border-border">
          {SECTIONS.map((section) => {
            const Icon = section.icon
            return (
              <button
                key={section.title}
                type="button"
                className="flex w-full items-center justify-between gap-4 py-6 text-left transition hover:bg-muted/40"
              >
                <div className="flex items-center gap-4">
                  <Icon className={section.danger ? 'h-5 w-5 text-red-500' : 'h-5 w-5 text-accent'} />
                  <div>
                    <div className={section.danger ? 'text-base font-medium text-red-600' : 'text-base font-medium'}>
                      {section.title}
                    </div>
                    <div className="text-sm text-muted-foreground">{section.body}</div>
                  </div>
                </div>
                <ChevronRight className="h-4 w-4 text-muted-foreground" />
              </button>
            )
          })}
        </div>
      </main>
      <Footer />
    </div>
  )
}
