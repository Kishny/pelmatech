import * as React from 'react'
import { createFileRoute } from '@tanstack/react-router'
import { ArrowUpRight } from 'lucide-react'

import blurDoctor from '@/assets/blur-doctor.png'
import happyDoctor from '@/assets/happy-doctor.png'
import youngDoctor from '@/assets/young-doctor.png'
import doctorConsultation from '@/assets/doctor-consultation.png'
import { AnimatedHeading } from '@/components/AnimatedHeading'
import { AnimatedText } from '@/components/AnimatedText'
import { DoctorCard } from '@/components/DoctorCard'
import { Footer } from '@/components/Footer'
import { Header } from '@/components/Header'

export const Route = createFileRoute('/doctors')({ component: Doctors })

const SPECIALTIES = [
  'All',
  'General Practice',
  'Pediatrics',
  'Cardiology',
  'Neurology',
  'Therapy',
  'Nutrition',
  'Dermatology',
  "Women's Health",
]

const DOCTORS = [
  { img: happyDoctor, name: 'Dr. Hana Sato', specialty: 'Neurology', availability: 'Next available: Today', experience: '12 yrs' },
  { img: youngDoctor, name: 'Dr. Matteo Dubois', specialty: 'Therapy', availability: 'Next available: Tomorrow', experience: '8 yrs' },
  { img: blurDoctor, name: 'Dr. Aria Vance', specialty: 'Cardiology', availability: 'Next available: Today', experience: '15 yrs' },
  { img: doctorConsultation, name: 'Dr. Kwame Mbeki', specialty: 'Pediatrics', availability: 'Next available: Fri', experience: '10 yrs' },
  { img: happyDoctor, name: 'Dr. Helga Brooks', specialty: 'General Practice', availability: 'Next available: Today', experience: '20 yrs' },
  { img: blurDoctor, name: 'Dr. Noor Farouk', specialty: "Women's Health", availability: 'Next available: Mon', experience: '9 yrs' },
]

function Doctors() {
  const [specialty, setSpecialty] = React.useState('All')

  const filtered =
    specialty === 'All' ? DOCTORS : DOCTORS.filter((d) => d.specialty === specialty)

  return (
    <div className="bg-background text-foreground">
      <Header variant="internal" />
      <main className="pt-40 pb-32 px-8 md:px-12">
        <AnimatedHeading as="h1" className="max-w-2xl text-5xl md:text-6xl font-medium leading-[1.05]">
          Find the right professional
          <br />
          for the right moment.
        </AnimatedHeading>
        <AnimatedText className="mt-6 max-w-xl text-base text-muted-foreground leading-relaxed">
          Filter by specialty, check real availability, and book directly
          with a professional you trust.
        </AnimatedText>

        <div className="mt-10 flex flex-wrap gap-3">
          {SPECIALTIES.map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => setSpecialty(s)}
              className={
                s === specialty
                  ? 'rounded-full bg-foreground px-4 py-2 text-sm text-white transition'
                  : 'rounded-full border border-border px-4 py-2 text-sm text-muted-foreground transition hover:bg-muted'
              }
            >
              {s}
            </button>
          ))}
        </div>

        <div className="mt-16 grid grid-cols-2 gap-8 md:grid-cols-3">
          {filtered.map((doc, i) => (
            <div key={doc.name}>
              <DoctorCard {...doc} delay={i * 0.06} />
              <button
                type="button"
                className="mt-4 flex items-center gap-1 text-sm font-medium text-foreground"
              >
                Book appointment
                <ArrowUpRight className="h-4 w-4" />
              </button>
            </div>
          ))}
        </div>
      </main>
      <Footer />
    </div>
  )
}
