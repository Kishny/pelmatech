import { createFileRoute } from '@tanstack/react-router'

import { AnimatedHeading } from '@/components/AnimatedHeading'
import { AnimatedText } from '@/components/AnimatedText'
import { Footer } from '@/components/Footer'
import { Header } from '@/components/Header'
import { PricingCard } from '@/components/PricingCard'

export const Route = createFileRoute('/pricing')({ component: Pricing })

/**
 * No prices are supplied by the spec, so plans use transparent
 * "Contact / Coming Soon" placeholders rather than fabricated figures.
 */
const PLANS = [
  {
    name: 'Free',
    price: 'Coming Soon',
    description: 'Get started with the essentials of everyday health tracking.',
    features: ['Basic health tracking', 'Appointment booking', 'FAQ & help center'],
  },
  {
    name: 'Personal',
    price: 'Contact for pricing',
    description: 'The full platform for one person, including telehealth and plans.',
    features: [
      'Everything in Free',
      'Telehealth consultations',
      'Personal health plan',
      'Medication management',
    ],
    featured: true,
  },
  {
    name: 'Family',
    price: 'Contact for pricing',
    description: 'Coordinate health management for everyone who depends on you.',
    features: [
      'Everything in Personal',
      'Family care tools',
      'Shared appointment calendar',
      'Priority support',
    ],
  },
]

function Pricing() {
  return (
    <div className="bg-background text-foreground">
      <Header variant="internal" />
      <main className="pt-40 pb-32 px-8 md:px-12">
        <AnimatedHeading as="h1" className="max-w-2xl text-5xl md:text-6xl font-medium leading-[1.05]">
          Plans for however
          <br />
          you want to be cared for.
        </AnimatedHeading>
        <AnimatedText className="mt-6 max-w-xl text-base text-muted-foreground leading-relaxed">
          Pricing details are being finalized — reach out and our team
          will help you find the right plan.
        </AnimatedText>

        <div className="mt-16 grid grid-cols-1 gap-6 md:grid-cols-3">
          {PLANS.map((plan) => (
            <PricingCard key={plan.name} {...plan} />
          ))}
        </div>
      </main>
      <Footer />
    </div>
  )
}
