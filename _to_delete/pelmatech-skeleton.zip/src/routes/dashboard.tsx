import { createFileRoute } from '@tanstack/react-router'
import { motion } from 'motion/react'
import type { ReactNode } from 'react'

import { Footer } from '@/components/Footer'
import { Header } from '@/components/Header'
import { HealthMetricCard } from '@/components/HealthMetricCard'
import { AppointmentCard } from '@/components/AppointmentCard'

export const Route = createFileRoute('/dashboard')({ component: Dashboard })

const METRICS = [
  { value: '86', label: 'Daily score' },
  { value: '6,420', label: 'Activity (steps)' },
  { value: '7h 10m', label: 'Sleep' },
  { value: '1.6 L', label: 'Hydration' },
]

/** Dashboard cards use the calmer "authenticated page" motion values, not the dramatic marketing clipping. */
function DashboardCard({ children, delay = 0 }: { children: ReactNode; delay?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.55, delay, ease: [0.22, 1, 0.36, 1] }}
      className="rounded-2xl border border-border bg-background p-6"
    >
      {children}
    </motion.div>
  )
}

function Dashboard() {
  return (
    <div className="bg-background text-foreground">
      <Header variant="internal" />
      <main className="pt-40 pb-32 px-8 md:px-12">
        <motion.h1
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
          className="text-3xl md:text-4xl font-medium leading-[1.05]"
        >
          Good morning, Alex.
          <br />
          Here's your health today.
        </motion.h1>

        <div className="mt-12 grid grid-cols-2 gap-4 md:grid-cols-4">
          {METRICS.map((m, i) => (
            <div key={m.label}>
              <HealthMetricCard {...m} delay={i * 0.05} />
            </div>
          ))}
        </div>

        <div className="mt-16 grid grid-cols-1 gap-8 md:grid-cols-2">
          <DashboardCard delay={0.1}>
            <h2 className="text-sm uppercase tracking-[0.2em] text-muted-foreground">
              Upcoming appointments
            </h2>
            <div className="mt-6">
              <AppointmentCard
                doctor="Dr. Hana Sato"
                specialty="Neurologist"
                date="Aug 15"
                time="10:30 AM"
                consultationType="Video"
                status="Upcoming"
              />
            </div>
          </DashboardCard>

          <DashboardCard delay={0.15}>
            <h2 className="text-sm uppercase tracking-[0.2em] text-muted-foreground">
              Medication reminders
            </h2>
            <ul className="mt-6 space-y-3 text-sm">
              <li className="flex items-center justify-between border-b border-border pb-3">
                <span>Vitamin D — 1 tablet</span>
                <span className="text-muted-foreground">08:00</span>
              </li>
              <li className="flex items-center justify-between">
                <span>Atorvastatin — 20mg</span>
                <span className="text-muted-foreground">21:00</span>
              </li>
            </ul>
          </DashboardCard>

          <DashboardCard delay={0.2}>
            <h2 className="text-sm uppercase tracking-[0.2em] text-muted-foreground">
              Nutrition goal
            </h2>
            <p className="mt-6 text-2xl font-medium">1,840 / 2,100 kcal</p>
          </DashboardCard>

          <DashboardCard delay={0.25}>
            <h2 className="text-sm uppercase tracking-[0.2em] text-muted-foreground">
              Today's workout
            </h2>
            <p className="mt-6 text-2xl font-medium">30 min — Mobility</p>
          </DashboardCard>
        </div>
      </main>
      <Footer />
    </div>
  )
}
