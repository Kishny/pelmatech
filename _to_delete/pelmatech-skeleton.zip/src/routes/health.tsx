import { createFileRoute } from '@tanstack/react-router'

import { AnimatedHeading } from '@/components/AnimatedHeading'
import { AnimatedText } from '@/components/AnimatedText'
import { Footer } from '@/components/Footer'
import { Header } from '@/components/Header'
import { HealthMetricCard } from '@/components/HealthMetricCard'

export const Route = createFileRoute('/health')({ component: HealthPage })

const METRICS = [
  { value: '72 bpm', label: 'Heart rate' },
  { value: '68 kg', label: 'Weight' },
  { value: '7h 42m', label: 'Sleep' },
  { value: '8,240', label: 'Activity (steps)' },
  { value: '2.1 L', label: 'Hydration' },
  { value: '118 / 76', label: 'Blood pressure' },
]

function HealthPage() {
  return (
    <div className="bg-background text-foreground">
      <Header variant="internal" />
      <main className="pt-40 pb-32 px-8 md:px-12">
        <AnimatedHeading as="h1" className="max-w-2xl text-5xl md:text-6xl font-medium leading-[1.05]">
          Know how you're doing.
        </AnimatedHeading>
        <AnimatedText className="mt-6 max-w-xl text-base text-muted-foreground leading-relaxed">
          A clear picture of your wellness trends over time — token-driven,
          never color-coded as your only signal.
        </AnimatedText>

        <div className="mt-16 grid grid-cols-2 gap-4 md:grid-cols-3">
          {METRICS.map((m, i) => (
            <HealthMetricCard key={m.label} {...m} delay={i * 0.05} />
          ))}
        </div>
      </main>
      <Footer />
    </div>
  )
}
