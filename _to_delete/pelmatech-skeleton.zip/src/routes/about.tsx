import { createFileRoute } from '@tanstack/react-router'

import { AnimatedHeading } from '@/components/AnimatedHeading'
import { AnimatedText } from '@/components/AnimatedText'
import { Footer } from '@/components/Footer'
import { Header } from '@/components/Header'
import { TeamSection } from '@/components/TeamSection'

export const Route = createFileRoute('/about')({ component: About })

const SECTIONS = [
  {
    title: 'Why Pelmatech exists',
    body: 'Healthcare is often fragmented across apps, waiting rooms, and paperwork. Pelmatech brings the pieces of everyday health management into one connected, human place.',
  },
  {
    title: 'Our approach',
    body: "We pair clear, honest health tracking with real access to trusted professionals — never one without the other.",
  },
  {
    title: 'Technology and care',
    body: 'Every feature is built to support a real relationship with your health and your care team, not to replace it.',
  },
  {
    title: 'Our values',
    body: 'Calm over chaos, clarity over jargon, and trust earned through consistent, careful design.',
  },
]

function About() {
  return (
    <div className="bg-background text-foreground">
      <Header variant="internal" />
      <main className="pt-40 pb-32 px-8 md:px-12">
        <AnimatedHeading as="h1" className="max-w-2xl text-5xl md:text-6xl font-medium leading-[1.05]">
          A personal health companion,
          <br />
          built around trust.
        </AnimatedHeading>

        <div className="mt-20 grid grid-cols-1 gap-16 md:grid-cols-2">
          {SECTIONS.map((section, i) => (
            <div key={section.title}>
              <AnimatedHeading as="h2" delay={i * 0.05} className="text-2xl font-medium">
                {section.title}
              </AnimatedHeading>
              <AnimatedText delay={i * 0.05} className="mt-4 text-base text-muted-foreground leading-relaxed">
                {section.body}
              </AnimatedText>
            </div>
          ))}
        </div>
      </main>

      <TeamSection />

      <Footer />
    </div>
  )
}
