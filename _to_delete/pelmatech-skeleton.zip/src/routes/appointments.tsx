import * as React from 'react'
import { createFileRoute } from '@tanstack/react-router'

import { AnimatedHeading } from '@/components/AnimatedHeading'
import { AnimatedText } from '@/components/AnimatedText'
import { AppointmentCard, type AppointmentCardProps } from '@/components/AppointmentCard'
import { Footer } from '@/components/Footer'
import { Header } from '@/components/Header'
import { Button } from '@/components/ui/button'

export const Route = createFileRoute('/appointments')({ component: Appointments })

const STEPS = [
  { number: '01', label: 'Choose a specialty' },
  { number: '02', label: 'Select a professional' },
  { number: '03', label: 'Pick a time' },
  { number: '04', label: 'Join your appointment' },
]

const APPOINTMENTS: Array<AppointmentCardProps> = [
  { doctor: 'Dr. Hana Sato', specialty: 'Neurologist', date: 'Aug 15', time: '10:30 AM', consultationType: 'Video', status: 'Upcoming' },
  { doctor: 'Dr. Matteo Dubois', specialty: 'Therapist', date: 'Aug 22', time: '3:00 PM', consultationType: 'In-person', status: 'Upcoming' },
  { doctor: 'Dr. Aria Vance', specialty: 'Cardiologist', date: 'Jul 30', time: '9:00 AM', consultationType: 'Video', status: 'Past' },
  { doctor: 'Dr. Kwame Mbeki', specialty: 'Pediatrician', date: 'Jul 12', time: '1:15 PM', consultationType: 'In-person', status: 'Cancelled' },
]

const TABS = ['Upcoming', 'Past', 'Cancelled'] as const

function Appointments() {
  const [tab, setTab] = React.useState<(typeof TABS)[number]>('Upcoming')

  return (
    <div className="bg-background text-foreground">
      <Header variant="internal" />
      <main className="pt-40 pb-32 px-8 md:px-12">
        <AnimatedHeading as="h1" className="max-w-2xl text-5xl md:text-6xl font-medium leading-[1.05]">
          Book care without
          <br />
          the back-and-forth.
        </AnimatedHeading>

        <div className="mt-16 grid grid-cols-2 gap-8 border-t border-border pt-10 md:grid-cols-4">
          {STEPS.map((step, i) => (
            <div key={step.number}>
              <AnimatedText as="span" delay={i * 0.1} className="text-xs tracking-[0.2em] text-muted-foreground uppercase">
                {step.number}
              </AnimatedText>
              <AnimatedText delay={i * 0.1} className="mt-2 text-base font-medium text-foreground">
                {step.label}
              </AnimatedText>
            </div>
          ))}
        </div>

        <div className="mt-20 flex items-center justify-between">
          <div className="flex gap-2">
            {TABS.map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setTab(t)}
                className={
                  t === tab
                    ? 'rounded-full bg-foreground px-4 py-2 text-sm text-white transition'
                    : 'rounded-full border border-border px-4 py-2 text-sm text-muted-foreground transition hover:bg-muted'
                }
              >
                {t}
              </button>
            ))}
          </div>
          <Button type="button">Book Appointment</Button>
        </div>

        <div className="mt-8 flex flex-col gap-4">
          {APPOINTMENTS.filter((a) => a.status === tab).map((a) => (
            <AppointmentCard key={`${a.doctor}-${a.date}`} {...a} />
          ))}
        </div>
      </main>
      <Footer />
    </div>
  )
}
