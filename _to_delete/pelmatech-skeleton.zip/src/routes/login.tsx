import { Link, createFileRoute } from '@tanstack/react-router'

import { AnimatedHeading } from '@/components/AnimatedHeading'
import { Header } from '@/components/Header'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'

export const Route = createFileRoute('/login')({ component: Login })

function Login() {
  return (
    <div className="bg-background text-foreground min-h-screen">
      <Header variant="internal" />
      <main className="flex min-h-screen items-center justify-center px-8 pt-24 pb-16 md:px-12">
        <div className="w-full max-w-sm">
          <AnimatedHeading as="h1" className="text-3xl font-medium">
            Welcome back
          </AnimatedHeading>

          <form className="mt-10 flex flex-col gap-6" onSubmit={(e) => e.preventDefault()}>
            <div className="flex flex-col gap-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" name="email" type="email" required />
            </div>
            <div className="flex flex-col gap-2">
              <Label htmlFor="password">Password</Label>
              <Input id="password" name="password" type="password" required />
            </div>

            <Button type="submit" className="mt-2">
              Sign In
            </Button>
          </form>

          <div className="mt-6 flex items-center justify-between text-sm text-muted-foreground">
            <button type="button" className="hover:text-foreground transition">
              Forgot Password
            </button>
            <Link to="/signup" className="hover:text-foreground transition">
              Create Account
            </Link>
          </div>
        </div>
      </main>
    </div>
  )
}
