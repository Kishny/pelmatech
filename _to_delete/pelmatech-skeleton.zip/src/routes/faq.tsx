import { createFileRoute } from '@tanstack/react-router'

import { AnimatedHeading } from '@/components/AnimatedHeading'
import { AnimatedText } from '@/components/AnimatedText'
import { AccordionItem } from '@/components/AccordionItem'
import { Accordion } from '@/components/ui/accordion'
import { Footer } from '@/components/Footer'
import { Header } from '@/components/Header'

export const Route = createFileRoute('/faq')({ component: FaqPage })

const CATEGORIES = [
  {
    name: 'Account',
    items: [
      { q: 'How do I create a Pelmatech account?', a: 'Select Create Account from the login page and follow the short setup flow — basic details, health goals, and preferences.' },
      { q: 'Can I use Pelmatech for family members?', a: 'Yes, family care tools let you help coordinate health management for the people who depend on you.' },
    ],
  },
  {
    name: 'Appointments',
    items: [
      { q: 'Can I book appointments online?', a: 'Yes. Choose a specialty, select a professional, pick a time, and join your appointment directly through Pelmatech.' },
      { q: 'Can I reschedule or cancel?', a: 'Yes, from the Appointments page you can manage upcoming, past, and cancelled visits.' },
    ],
  },
  {
    name: 'Health Tracking',
    items: [
      { q: 'How does health tracking work?', a: "Pelmatech brings together the health signals that matter to you — activity, heart rate, sleep, weight, hydration, and wellness trends — into one clear view." },
    ],
  },
  {
    name: 'Doctors',
    items: [
      { q: 'Can Pelmatech replace my doctor?', a: 'No. Pelmatech is designed to support everyday health management and communication. It does not replace emergency services or professional medical diagnosis.' },
    ],
  },
  {
    name: 'Privacy',
    items: [
      { q: 'How is my information protected?', a: 'Pelmatech is designed with strong privacy and security practices, including encrypted data, secure authentication, and clear permission controls.' },
    ],
  },
  {
    name: 'Billing',
    items: [
      { q: 'What does Pelmatech cost?', a: 'Pricing details are being finalized. Visit the Pricing page or contact us for current plan information.' },
    ],
  },
]

function FaqPage() {
  return (
    <div className="bg-background text-foreground">
      <Header variant="internal" />
      <main className="pt-40 pb-32 px-8 md:px-12">
        <AnimatedHeading as="h1" className="max-w-2xl text-5xl md:text-6xl font-medium leading-[1.05]">
          Questions,
          <br />
          answered clearly.
        </AnimatedHeading>
        <AnimatedText className="mt-6 max-w-xl text-base text-muted-foreground leading-relaxed">
          Pelmatech is designed to support everyday health management and
          communication. It does not replace emergency services or
          professional medical diagnosis.
        </AnimatedText>

        <div className="mt-20 grid grid-cols-1 gap-16 md:grid-cols-2">
          {CATEGORIES.map((cat) => (
            <div key={cat.name}>
              <h2 className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
                {cat.name}
              </h2>
              <Accordion type="single" collapsible className="mt-4">
                {cat.items.map((item, i) => (
                  <AccordionItem
                    key={item.q}
                    value={`${cat.name}-${i}`}
                    question={item.q}
                    answer={item.a}
                  />
                ))}
              </Accordion>
            </div>
          ))}
        </div>
      </main>
      <Footer />
    </div>
  )
}
