import { Activity, Calendar, Apple, Dumbbell } from 'lucide-react'

import { AnimatedHeading } from '@/components/AnimatedHeading'
import { AnimatedText } from '@/components/AnimatedText'

const PILLARS = [
  { number: '01', title: 'Health Tracking', icon: Activity, body: 'Keep every vital sign, habit, and trend in one clear picture.' },
  { number: '02', title: 'Appointments', icon: Calendar, body: 'Book, reschedule, and join visits without the back-and-forth.' },
  { number: '03', title: 'Nutrition', icon: Apple, body: 'Log meals and stay aligned with your personal targets.' },
  { number: '04', title: 'Fitness', icon: Dumbbell, body: 'Plan workouts and track activity as your routine evolves.' },
] as const

/**
 * Platform Overview — the first new section after Benefits (spec
 * section 5). Must feel seamless with the protected foundation above
 * it. 4-pillar "PLATFORM FEATURE GRID".
 */
export function FeaturesSection() {
  return (
    <section className="py-32 px-8 md:px-12 bg-background">
      <div
        className="mb-16 flex gap-24 tracking-[0.2em] uppercase text-muted-foreground"
        style={{ fontSize: '11.26px' }}
      >
        <span>Pelmatech</span>
        <span>Your Health, Connected</span>
      </div>

      <AnimatedHeading as="h2" className="max-w-3xl font-medium leading-[1.05]" style={{ fontSize: '58px' }}>
        Everything your health needs,
        <br />
        in one connected place.
      </AnimatedHeading>

      <AnimatedText className="mt-6 max-w-xl text-base text-muted-foreground leading-relaxed">
        From daily wellness tracking to appointments and health records,
        Pelmatech helps bring the pieces of your care together.
      </AnimatedText>

      <div className="mt-20 grid grid-cols-1 divide-y divide-border border-t border-border md:grid-cols-4 md:divide-x md:divide-y-0">
        {PILLARS.map((pillar, i) => {
          const Icon = pillar.icon
          return (
            <div key={pillar.number} className="flex flex-col gap-6 py-10 md:px-8 md:py-0 md:pt-10">
              <AnimatedText as="span" delay={i * 0.1} className="text-xs tracking-[0.2em] text-muted-foreground uppercase">
                {pillar.number}
              </AnimatedText>
              <Icon className="h-6 w-6 text-accent" />
              <AnimatedHeading as="h3" delay={i * 0.1} className="text-xl font-medium">
                {pillar.title}
              </AnimatedHeading>
              <AnimatedText delay={i * 0.1} className="text-sm text-muted-foreground leading-relaxed">
                {pillar.body}
              </AnimatedText>
            </div>
          )
        })}
      </div>
    </section>
  )
}
