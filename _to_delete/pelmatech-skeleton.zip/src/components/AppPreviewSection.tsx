import mobileApp from '@/assets/mobile-app.png'
import { AnimatedHeading } from '@/components/AnimatedHeading'
import { AnimatedText } from '@/components/AnimatedText'
import { MaskedImage } from '@/components/MaskedImage'

const HIGHLIGHTS = [
  'Daily dashboard',
  'Appointment notifications',
  'Medication reminders',
  'Health goals',
  'Doctor messaging',
]

/** Mobile App Preview. */
export function AppPreviewSection() {
  return (
    <section className="py-32 px-8 md:px-12 bg-background overflow-hidden">
      <div className="grid grid-cols-1 gap-16 md:grid-cols-2 md:items-center">
        <div>
          <AnimatedHeading as="h2" className="max-w-md text-4xl md:text-5xl font-medium leading-[1.05]">
            Your health companion,
            <br />
            wherever you are.
          </AnimatedHeading>

          <ul className="mt-8 space-y-3">
            {HIGHLIGHTS.map((h) => (
              <li key={h} className="flex items-center gap-3 text-sm text-foreground">
                <span className="h-1.5 w-1.5 rounded-full bg-accent" />
                {h}
              </li>
            ))}
          </ul>

          <AnimatedText delay={0.3}>
            <button
              type="button"
              className="mt-10 bg-foreground text-white rounded-full px-6 py-3 text-sm font-medium hover:opacity-90 transition"
            >
              Get Started
            </button>
          </AnimatedText>
        </div>

        <MaskedImage
          src={mobileApp}
          alt="Pelmatech mobile app"
          className="mx-auto aspect-[9/16] w-full max-w-sm"
        />
      </div>
    </section>
  )
}
