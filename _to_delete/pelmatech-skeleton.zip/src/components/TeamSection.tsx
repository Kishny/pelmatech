import { AnimatedHeading } from '@/components/AnimatedHeading'
import { AnimatedText } from '@/components/AnimatedText'
import { TeamCarousel } from '@/components/TeamCarousel'

const TEAM_FONT =
  '"TT Hoves", "Helvetica Neue", Helvetica, Arial, sans-serif'

/**
 * PROTECTED SECTION — 335.26px heading offset, TT Hoves font stack, and
 * exact type sizes must not change.
 */
export function TeamSection() {
  return (
    <section className="py-32 px-8 md:px-12" style={{ fontFamily: TEAM_FONT }}>
      <div
        className="mb-16 flex gap-24 tracking-[0.2em] uppercase text-muted-foreground"
        style={{ fontSize: '11.26px', fontFamily: TEAM_FONT }}
      >
        <span>Pelmatech</span>
        <span>Our Team</span>
      </div>

      <div
        className="mb-20 flex flex-col items-start justify-between gap-10 md:flex-row md:items-end"
        style={{ paddingLeft: '335.26px' }}
      >
        <AnimatedHeading as="h2" style={{ fontFamily: TEAM_FONT }}>
          <span
            style={{
              fontSize: '58.55px',
              lineHeight: 1.05,
              display: 'block',
              fontFamily: TEAM_FONT,
            }}
          >
            Get to Know the People
            <br />
            that Get It All Done
          </span>
        </AnimatedHeading>

        <AnimatedText as="span" delay={0.15}>
          <span
            style={{
              fontSize: '16.89px',
              lineHeight: 1.5,
              display: 'block',
              width: '270px',
              fontFamily: TEAM_FONT,
            }}
          >
            On our platform, our devoted team works ceaselessly to enhance
            our online presence and ensure the best possible customer
            experience.
          </span>
        </AnimatedText>
      </div>

      <TeamCarousel />
    </section>
  )
}
