import * as React from 'react'
import { AnimatePresence, motion } from 'motion/react'
import { ArrowLeft, ArrowRight } from 'lucide-react'

import blurDoctor from '@/assets/blur-doctor.png'
import happyDoctor from '@/assets/happy-doctor.png'
import youngDoctor from '@/assets/young-doctor.png'
import { MaskedImage } from '@/components/MaskedImage'

/**
 * PROTECTED CAROUSEL GEOMETRY — exact values, do not alter.
 */
const INTRO_WIDTH = 324
const GAP = 11.26
const visible = 3.25

const team = [
  { img: blurDoctor, role: 'SURGEON GENERAL', name: 'Dr. Helga Brooks' },
  { img: happyDoctor, role: 'PEDIATRICIAN', name: 'Dr. Kwame Mbeki' },
  { img: youngDoctor, role: 'THERAPIST', name: 'Dr. Matteo Dubois' },
  { img: happyDoctor, role: 'NEUROLOGIST', name: 'Dr. Hana Sato' },
  { img: blurDoctor, role: 'CARDIOLOGIST', name: 'Dr. Aria Vance' },
]

const maxIndex = Math.max(0, Math.ceil(team.length - visible))

export function TeamCarousel() {
  const [index, setIndex] = React.useState(0)
  const [hovered, setHovered] = React.useState(false)

  function goTo(next: number) {
    setIndex(Math.min(Math.max(next, 0), maxIndex))
  }

  return (
    <div
      className="relative"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div className="overflow-hidden">
        <motion.div
          className="flex"
          style={{
            gap: 11.26,
            width: `calc(${team.length} * ((100% - ${(visible - 1) * GAP}px) / ${visible}) + ${(team.length - 1) * GAP}px)`,
          }}
          animate={{
            x: `calc(${-index} * (100% + ${GAP}px) / ${team.length})`,
          }}
          transition={{
            duration: 0.7,
            ease: [0.22, 1, 0.36, 1],
          }}
        >
          {team.map((member, i) => (
            <div
              key={`${member.name}-${i}`}
              style={{
                width: `calc((100% - ${(visible - 1) * GAP}px) / ${visible})`,
                minWidth: INTRO_WIDTH,
              }}
            >
              <div className="aspect-[3/4] overflow-hidden bg-muted">
                <MaskedImage
                  src={member.img}
                  alt={member.name}
                  delay={i * 0.08}
                  className="h-full w-full"
                />
              </div>
              <div className="pt-6">
                <div className="text-xs tracking-[0.2em] text-muted-foreground uppercase">
                  {member.role}
                </div>
                <div className="text-xl mt-2 font-medium">{member.name}</div>
              </div>
            </div>
          ))}
        </motion.div>
      </div>

      {/*
        HOVER PUCK — the spec defines exact geometry/blur for this
        element but not its internal content or precise interaction. We
        make it a click target that advances the carousel, matching its
        name ("control puck"), and leave this comment per the
        reproduce-exactly clause's guidance for unspecified details.
      */}
      <AnimatePresence>
        {hovered && (
          <button
            type="button"
            aria-label="Next team member"
            onClick={() => goTo(index >= maxIndex ? 0 : index + 1)}
            className="absolute top-[35%] left-1/2 -translate-x-1/2 -translate-y-1/2 z-10 flex items-center justify-center rounded-full"
          >
            <motion.span
              initial={{ opacity: 0, scale: 0.85 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.85 }}
              transition={{ duration: 0.25 }}
              className="flex items-center justify-center rounded-full"
              style={{
                width: 126,
                height: 126,
                background: 'rgba(72, 72, 72, 0.16)',
                backdropFilter: 'blur(84px)',
                WebkitBackdropFilter: 'blur(84px)',
              }}
            >
              <ArrowRight className="h-5 w-5 text-white" />
            </motion.span>
          </button>
        )}
      </AnimatePresence>

      {/* Accessible, always-visible carousel controls */}
      <div className="mt-8 flex items-center gap-3">
        <button
          type="button"
          aria-label="Previous team member"
          disabled={index === 0}
          onClick={() => goTo(index - 1)}
          className="flex h-10 w-10 items-center justify-center rounded-full border border-border text-foreground transition hover:bg-muted disabled:opacity-30"
        >
          <ArrowLeft className="h-4 w-4" />
        </button>
        <button
          type="button"
          aria-label="Next team member"
          disabled={index === maxIndex}
          onClick={() => goTo(index + 1)}
          className="flex h-10 w-10 items-center justify-center rounded-full border border-border text-foreground transition hover:bg-muted disabled:opacity-30"
        >
          <ArrowRight className="h-4 w-4" />
        </button>
      </div>
    </div>
  )
}
