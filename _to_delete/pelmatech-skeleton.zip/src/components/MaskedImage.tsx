import { motion } from 'motion/react'

import { cn } from '@/lib/utils'

/**
 * PROTECTED MOTION PRIMITIVE — do not alter the transition values below,
 * and never substitute this with a plain opacity fade. This is the
 * default image reveal across the complete website (clip-path mask).
 */
interface MaskedImageProps {
  src: string
  alt: string
  className?: string
  imgClassName?: string
  delay?: number
}

export function MaskedImage({
  src,
  alt,
  className,
  imgClassName,
  delay = 0,
}: MaskedImageProps) {
  return (
    <motion.div
      className={cn('overflow-hidden', className)}
      initial={{
        clipPath: 'inset(100% 0 0 0)',
      }}
      whileInView={{
        clipPath: 'inset(0% 0 0 0)',
      }}
      viewport={{
        once: true,
        margin: '-80px',
      }}
      transition={{
        duration: 1.1,
        delay,
        ease: [0.22, 1, 0.36, 1],
      }}
    >
      <img
        src={src}
        alt={alt}
        className={cn('w-full h-full object-cover', imgClassName)}
      />
    </motion.div>
  )
}
