import * as React from 'react'
import { ArrowLeft, ArrowRight } from 'lucide-react'

import { AnimatedHeading } from '@/components/AnimatedHeading'
import { AnimatedText } from '@/components/AnimatedText'
import { TestimonialCard } from '@/components/TestimonialCard'

const TESTIMONIALS = [
  {
    quote:
      "I finally have one place where I can understand my appointments, habits, and goals without jumping between five different apps.",
    name: 'Sofia, 30s',
    meta: 'Using Pelmatech for health tracking & telehealth',
  },
  {
    quote:
      'Booking a same-day consultation used to be the hardest part of getting help. Now it takes two minutes.',
    name: 'Marcus, 40s',
    meta: 'Uses Pelmatech for appointments & medications',
  },
  {
    quote:
      "My care team and my own tracking finally talk to each other. It changed how seriously I take my check-ins.",
    name: 'Elena, 50s',
    meta: 'Uses Pelmatech for family care',
  },
]

/** Testimonials — human, credible quotes; no fake logo walls. */
export function TestimonialsSection() {
  const [index, setIndex] = React.useState(0)
  const max = TESTIMONIALS.length - 1

  return (
    <section className="py-32 px-8 md:px-12 bg-background">
      <div className="flex items-end justify-between gap-8">
        <AnimatedHeading as="h2" className="max-w-2xl text-4xl md:text-5xl font-medium leading-[1.05]">
          Health feels different
          <br />
          when you're not doing it alone.
        </AnimatedHeading>

        <div className="hidden shrink-0 items-center gap-3 md:flex">
          <button
            type="button"
            aria-label="Previous testimonial"
            disabled={index === 0}
            onClick={() => setIndex((i) => Math.max(0, i - 1))}
            className="flex h-10 w-10 items-center justify-center rounded-full border border-border transition hover:bg-muted disabled:opacity-30"
          >
            <ArrowLeft className="h-4 w-4" />
          </button>
          <button
            type="button"
            aria-label="Next testimonial"
            disabled={index === max}
            onClick={() => setIndex((i) => Math.min(max, i + 1))}
            className="flex h-10 w-10 items-center justify-center rounded-full border border-border transition hover:bg-muted disabled:opacity-30"
          >
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </div>

      <AnimatedText className="mt-16 sr-only">
        Testimonial {index + 1} of {TESTIMONIALS.length}
      </AnimatedText>

      <div className="mt-16 grid grid-cols-1 gap-6 md:grid-cols-3">
        {TESTIMONIALS.map((t) => (
          <TestimonialCard key={t.name} {...t} />
        ))}
      </div>
    </section>
  )
}
