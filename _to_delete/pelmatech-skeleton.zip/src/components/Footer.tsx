import logoWhite from '@/assets/logo.svg'

const COLUMNS = [
  {
    title: 'Platform',
    links: ['Health Tracking', 'Appointments', 'Nutrition', 'Fitness', 'Medications'],
  },
  {
    title: 'Company',
    links: ['About', 'Our Team', 'Careers', 'Contact'],
  },
  {
    title: 'Professionals',
    links: ['Join Pelmatech', 'Doctor Portal', 'Resources'],
  },
  {
    title: 'Support',
    links: ['Help Center', 'FAQ', 'Accessibility'],
  },
  {
    title: 'Legal',
    links: ['Privacy', 'Terms', 'Cookies'],
  },
] as const

export function Footer() {
  return (
    <footer className="bg-foreground text-white px-8 py-20 md:px-12">
      <div className="grid grid-cols-2 gap-10 sm:grid-cols-3 md:grid-cols-6">
        <div className="col-span-2 sm:col-span-3 md:col-span-1">
          <img src={logoWhite} alt="Pelmatech" className="h-8 w-auto" />
        </div>
        {COLUMNS.map((col) => (
          <div key={col.title}>
            <div className="text-xs uppercase tracking-[0.2em] text-white/50">{col.title}</div>
            <ul className="mt-4 space-y-2">
              {col.links.map((link) => (
                <li key={link}>
                  <span className="text-sm text-white/70 hover:text-white transition cursor-pointer">
                    {link}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="mt-16 flex flex-col items-start justify-between gap-4 border-t border-white/10 pt-8 text-xs text-white/50 sm:flex-row sm:items-center">
        <span>© Pelmatech</span>
        <span>Your Personal Health Companion</span>
      </div>
    </footer>
  )
}
