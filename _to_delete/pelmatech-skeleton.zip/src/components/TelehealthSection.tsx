import { ArrowUpRight } from 'lucide-react'

import telehealth from '@/assets/telehealth.png'
import { AnimatedHeading } from '@/components/AnimatedHeading'
import { AnimatedText } from '@/components/AnimatedText'
import { MaskedImage } from '@/components/MaskedImage'

const POINTS = [
  'Secure video appointments',
  'Verified professionals',
  'Flexible scheduling',
  'Follow-up messaging',
]

/** Telehealth — split layout, image left / content right. */
export function TelehealthSection() {
  return (
    <section className="py-32 px-8 md:px-12 bg-background">
      <div className="grid grid-cols-1 gap-16 md:grid-cols-2 md:items-center">
        <MaskedImage src={telehealth} alt="Telehealth video consultation" className="aspect-[4/3] w-full order-2 md:order-1" />

        <div className="order-1 md:order-2">
          <AnimatedHeading as="h2" className="text-4xl md:text-5xl font-medium leading-[1.05]">
            Care, when you need it.
          </AnimatedHeading>

          <AnimatedText className="mt-6 max-w-md text-base text-muted-foreground leading-relaxed">
            Connect with qualified health professionals without losing
            hours to travel, waiting rooms, or scheduling friction.
          </AnimatedText>

          <ul className="mt-8 space-y-3">
            {POINTS.map((p) => (
              <li key={p} className="flex items-center gap-3 text-sm text-foreground">
                <span className="h-1.5 w-1.5 rounded-full bg-accent" />
                {p}
              </li>
            ))}
          </ul>

          <div className="mt-10 flex items-center gap-6">
            <button
              type="button"
              className="bg-foreground text-white rounded-full pl-6 pr-2 py-2 flex items-center gap-3 font-medium text-sm hover:opacity-90 transition"
            >
              Find a Doctor
              <span className="w-9 h-9 rounded-full bg-white/15 flex items-center justify-center">
                <ArrowUpRight className="w-4 h-4" />
              </span>
            </button>
            <button type="button" className="flex items-center gap-1 text-sm font-medium text-foreground">
              How Telehealth Works
              <ArrowUpRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </section>
  )
}
