import { Accordion } from '@/components/ui/accordion'
import { AccordionItem } from '@/components/AccordionItem'
import { AnimatedHeading } from '@/components/AnimatedHeading'
import { AnimatedText } from '@/components/AnimatedText'

const QUESTIONS = [
  {
    question: 'What is Pelmatech?',
    answer:
      'Pelmatech is a digital personal health companion that helps you understand, organize, monitor, and improve your health while keeping access to trusted professionals.',
  },
  {
    question: 'Can I book appointments online?',
    answer:
      'Yes. You can choose a specialty, select a professional, pick a time, and join your appointment directly through Pelmatech.',
  },
  {
    question: 'Can Pelmatech replace my doctor?',
    answer:
      'No. Pelmatech is designed to support everyday health management and communication. It does not replace emergency services or professional medical diagnosis.',
  },
  {
    question: 'How does health tracking work?',
    answer:
      'Pelmatech brings together the health signals that matter to you — activity, heart rate, sleep, weight, hydration, and wellness trends — into one clear view.',
  },
  {
    question: 'Can I manage medications?',
    answer:
      'Yes. Keep medications organized with schedules, reminders, refill awareness, and a clear history.',
  },
  {
    question: 'How is my information protected?',
    answer:
      'Pelmatech is designed with strong privacy and security practices, including encrypted data, secure authentication, and clear permission controls.',
  },
  {
    question: 'Can I use Pelmatech for family members?',
    answer:
      'Yes, family care tools let you help coordinate health management for the people who depend on you.',
  },
]

export function FAQ() {
  return (
    <section className="py-32 px-8 md:px-12 bg-surface">
      <div className="grid grid-cols-1 gap-16 md:grid-cols-3">
        <div>
          <AnimatedHeading as="h2" className="text-4xl md:text-5xl font-medium leading-[1.05]">
            Questions,
            <br />
            answered clearly.
          </AnimatedHeading>
          <AnimatedText className="mt-6 max-w-xs text-sm text-muted-foreground leading-relaxed">
            Pelmatech is designed to support everyday health management
            and communication. It does not replace emergency services or
            professional medical diagnosis.
          </AnimatedText>
        </div>

        <div className="md:col-span-2">
          <Accordion type="single" collapsible>
            {QUESTIONS.map((q, i) => (
              <AccordionItem key={q.question} value={`item-${i}`} question={q.question} answer={q.answer} />
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  )
}
