import { ShieldCheck, Lock, Eye, KeyRound, MessageCircle } from 'lucide-react'

import { AnimatedHeading } from '@/components/AnimatedHeading'
import { AnimatedText } from '@/components/AnimatedText'

const POINTS = [
  { icon: Lock, label: 'Encrypted data' },
  { icon: KeyRound, label: 'Secure authentication' },
  { icon: Eye, label: 'Privacy controls' },
  { icon: ShieldCheck, label: 'Clear permissions' },
  { icon: MessageCircle, label: 'Protected professional communication' },
]

/**
 * Security / Privacy — do not claim HIPAA/GDPR compliance or
 * certifications; use "designed with strong privacy and security
 * practices" language only, per spec.
 */
export function SecuritySection() {
  return (
    <section className="py-32 px-8 md:px-12 bg-surface">
      <div className="grid grid-cols-1 gap-16 md:grid-cols-2 md:items-start">
        <div>
          <ShieldCheck className="h-8 w-8 text-accent" />
          <AnimatedHeading as="h2" className="mt-6 max-w-md text-4xl md:text-5xl font-medium leading-[1.05]">
            Your health information
            <br />
            deserves serious protection.
          </AnimatedHeading>
          <AnimatedText className="mt-6 max-w-md text-base text-muted-foreground leading-relaxed">
            Designed with strong privacy and security practices at every
            layer of the platform.
          </AnimatedText>
        </div>

        <ul className="space-y-6">
          {POINTS.map((point) => {
            const Icon = point.icon
            return (
              <li key={point.label} className="flex items-center gap-4 border-b border-border pb-6">
                <Icon className="h-5 w-5 shrink-0 text-accent" />
                <span className="text-base text-foreground">{point.label}</span>
              </li>
            )
          })}
        </ul>
      </div>
    </section>
  )
}
