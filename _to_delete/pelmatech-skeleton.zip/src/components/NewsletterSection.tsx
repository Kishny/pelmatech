import { ArrowUpRight } from 'lucide-react'

import { AnimatedHeading } from '@/components/AnimatedHeading'
import { AnimatedText } from '@/components/AnimatedText'

/** Final CTA — bg-foreground, reuses hero button styling. */
export function NewsletterSection() {
  return (
    <section className="py-32 px-8 md:px-12 bg-foreground text-white">
      <div className="flex flex-col items-start justify-between gap-10 md:flex-row md:items-end">
        <div>
          <AnimatedHeading as="h2" className="max-w-xl text-4xl md:text-6xl font-medium leading-[1.05] text-white">
            Take better care
            <br />
            of your everyday health.
          </AnimatedHeading>
          <AnimatedText className="mt-6 max-w-md text-base text-white/70 leading-relaxed">
            Start building a clearer, more connected view of your health
            with Pelmatech.
          </AnimatedText>
        </div>

        <div className="flex items-center gap-6 shrink-0">
          <button
            type="button"
            className="bg-white text-foreground rounded-full pl-6 pr-2 py-2 flex items-center gap-3 font-medium text-sm hover:bg-white/90 transition"
          >
            Try for Free
            <span className="w-9 h-9 rounded-full bg-foreground text-white flex items-center justify-center">
              <ArrowUpRight className="w-4 h-4" />
            </span>
          </button>
          <button type="button" className="text-white flex items-center gap-1 text-sm font-medium">
            Schedule Demo
            <ArrowUpRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </section>
  )
}
