import healthData from '@/assets/health-data.png'
import { AnimatedHeading } from '@/components/AnimatedHeading'
import { AnimatedText } from '@/components/AnimatedText'
import { HealthMetricCard } from '@/components/HealthMetricCard'
import { MaskedImage } from '@/components/MaskedImage'

const METRICS = [
  { value: '8,240', label: 'Steps today' },
  { value: '72 bpm', label: 'Resting heart rate' },
  { value: '7h 42m', label: 'Sleep' },
  { value: '2.1 L', label: 'Hydration' },
]

const SIGNALS = ['Activity', 'Heart rate', 'Sleep', 'Weight', 'Hydration', 'Wellness trends']

/** Health Tracking — editorial dashboard showcase, bg-surface. */
export function HealthTrackingSection() {
  return (
    <section className="py-32 px-8 md:px-12 bg-surface">
      <div className="grid grid-cols-1 gap-16 md:grid-cols-2 md:items-center">
        <div>
          <AnimatedHeading as="h2" className="text-4xl md:text-5xl font-medium leading-[1.05]">
            Know how you're doing.
            <br />
            Not just how you're feeling.
          </AnimatedHeading>

          <AnimatedText className="mt-6 max-w-md text-base text-muted-foreground leading-relaxed">
            Track the health signals that matter to you and keep a clear
            picture of your progress over time.
          </AnimatedText>

          <div className="mt-8 flex flex-wrap gap-2">
            {SIGNALS.map((s) => (
              <span key={s} className="rounded-full bg-background px-4 py-2 text-xs text-muted-foreground border border-border">
                {s}
              </span>
            ))}
          </div>

          <div className="mt-10 grid grid-cols-2 gap-4">
            {METRICS.map((m, i) => (
              <HealthMetricCard key={m.label} {...m} delay={i * 0.1} />
            ))}
          </div>
        </div>

        <MaskedImage
          src={healthData}
          alt="Pelmatech health tracking dashboard"
          className="aspect-[4/3] w-full"
        />
      </div>
    </section>
  )
}
