import blurDoctor from '@/assets/blur-doctor.png'
import happyDoctor from '@/assets/happy-doctor.png'
import youngDoctor from '@/assets/young-doctor.png'
import doctorConsultation from '@/assets/doctor-consultation.png'
import { AnimatedHeading } from '@/components/AnimatedHeading'
import { AnimatedText } from '@/components/AnimatedText'
import { DoctorCard } from '@/components/DoctorCard'

const SPECIALTIES = [
  'General Practice',
  'Pediatrics',
  'Cardiology',
  'Neurology',
  'Therapy',
  'Nutrition',
  'Dermatology',
  "Women's Health",
]

const DOCTORS = [
  { img: happyDoctor, name: 'Dr. Hana Sato', specialty: 'Neurologist', availability: 'Next available: Today', experience: '12 yrs' },
  { img: youngDoctor, name: 'Dr. Matteo Dubois', specialty: 'Therapist', availability: 'Next available: Tomorrow', experience: '8 yrs' },
  { img: blurDoctor, name: 'Dr. Aria Vance', specialty: 'Cardiologist', availability: 'Next available: Today', experience: '15 yrs' },
  { img: doctorConsultation, name: 'Dr. Kwame Mbeki', specialty: 'Pediatrician', availability: 'Next available: Fri', experience: '10 yrs' },
]

/**
 * Doctor Discovery (spec section 8) — bg-background, reuses the
 * TeamCarousel visual language via DoctorCard, as instructed.
 */
export function PlatformSection() {
  return (
    <section className="py-32 px-8 md:px-12 bg-background">
      <AnimatedHeading as="h2" className="text-5xl md:text-6xl font-medium leading-[1.05] max-w-3xl">
        Find the right professional
        <br />
        for the right moment.
      </AnimatedHeading>

      <AnimatedText className="mt-6 max-w-xl text-base text-muted-foreground leading-relaxed">
        Browse specialties, check real availability, and book with a
        professional who matches how you want to be cared for.
      </AnimatedText>

      <div className="mt-10 flex flex-wrap gap-3">
        {SPECIALTIES.map((s) => (
          <span
            key={s}
            className="rounded-full border border-border px-4 py-2 text-sm text-muted-foreground"
          >
            {s}
          </span>
        ))}
      </div>

      <div className="mt-16 grid grid-cols-2 gap-8 md:grid-cols-4">
        {DOCTORS.map((doc, i) => (
          <DoctorCard key={doc.name} {...doc} delay={i * 0.08} />
        ))}
      </div>
    </section>
  )
}
