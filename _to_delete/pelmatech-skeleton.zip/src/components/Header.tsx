import * as React from 'react'
import { Link } from '@tanstack/react-router'
import { Menu } from 'lucide-react'

import logoWhite from '@/assets/logo.svg'
import logoDark from '@/assets/logo-dark.svg'
import { MobileMenu } from '@/components/MobileMenu'

const PROTECTED_NAV = ['Home', 'Artists', 'Releases', 'Contact'] as const

interface HeaderProps {
  /**
   * Pages without the full-screen dark hero (everything except the
   * homepage) start with the dark logo and a lighter nav pill for
   * readability, per "HEADER BEHAVIOR ON INTERNAL PAGES".
   */
  variant?: 'hero' | 'internal'
}

/**
 * PROTECTED SECTION — geometry, spacing, and interaction language must
 * not change. Only the logo-swap trigger point and the header pill
 * background differ between the homepage hero and internal pages.
 */
export function Header({ variant = 'hero' }: HeaderProps) {
  const [scrolledPastHero, setScrolledPastHero] = React.useState(
    variant === 'internal',
  )
  const [menuOpen, setMenuOpen] = React.useState(false)

  React.useEffect(() => {
    if (variant === 'internal') return

    function onScroll() {
      setScrolledPastHero(window.scrollY > window.innerHeight - 80)
    }
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [variant])

  const isDarkLogo = variant === 'internal' || scrolledPastHero

  return (
    <>
      <header className="fixed top-6 left-0 right-0 z-50 px-8 flex items-center justify-between">
        <Link to="/" aria-label="Pelmatech home">
          <img
            src={isDarkLogo ? logoDark : logoWhite}
            alt="Pelmatech"
            className="h-8 w-auto transition-opacity"
          />
        </Link>

        <div
          className="flex items-center gap-1 rounded-full pl-2 pr-2 py-2 backdrop-blur-md transition-colors"
          style={{
            background:
              variant === 'internal'
                ? 'var(--surface)'
                : 'var(--header-bg)',
            color: variant === 'internal' ? 'var(--foreground)' : '#fff',
          }}
        >
          {PROTECTED_NAV.map((label, i) => (
            <a
              key={label}
              href={i === 0 ? '/' : '#'}
              className={
                i === 0
                  ? 'px-5 py-2 text-sm rounded-full bg-white/10 font-medium'
                  : 'px-5 py-2 text-sm rounded-full opacity-80 hover:opacity-100 transition'
              }
            >
              {label}
            </a>
          ))}

          <button
            type="button"
            onClick={() => setMenuOpen(true)}
            aria-expanded={menuOpen}
            aria-controls="site-menu-panel"
            className="ml-2 flex items-center gap-2 px-4 py-2 text-sm rounded-full hover:bg-white/10 transition"
          >
            <Menu className="w-4 h-4" />
            Menu
          </button>
        </div>
      </header>

      <div id="site-menu-panel">
        <MobileMenu open={menuOpen} onClose={() => setMenuOpen(false)} />
      </div>
    </>
  )
}
