import { AnimatedHeading } from '@/components/AnimatedHeading'
import { AnimatedText } from '@/components/AnimatedText'

const PLAN_ITEMS = [
  'Daily goals',
  'Nutrition targets',
  'Movement plan',
  'Medication schedule',
  'Appointment reminders',
  'Progress reviews',
]

/** Personal Health Plan — bg-foreground, white text, restrained UI. */
export function PersonalPlanSection() {
  return (
    <section className="py-32 px-8 md:px-12 bg-foreground text-white">
      <div className="grid grid-cols-1 gap-16 md:grid-cols-2">
        <div>
          <AnimatedHeading as="h2" className="text-4xl md:text-5xl font-medium leading-[1.05] text-white">
            A plan that changes
            <br />
            when your life does.
          </AnimatedHeading>

          <AnimatedText className="mt-6 max-w-md text-base text-white/70 leading-relaxed">
            Pelmatech brings your goals, routines, health data, and
            professional guidance into a plan you can actually follow.
          </AnimatedText>

          <button
            type="button"
            className="mt-10 bg-white text-foreground rounded-full px-6 py-3 text-sm font-medium hover:bg-white/90 transition"
          >
            Build My Health Plan
          </button>
        </div>

        <ul className="grid grid-cols-1 gap-px overflow-hidden rounded-2xl border border-white/15 sm:grid-cols-2">
          {PLAN_ITEMS.map((item) => (
            <li
              key={item}
              className="flex items-center bg-white/[0.03] px-6 py-8 text-sm text-white/80 border-white/10 [&:not(:last-child)]:border-b sm:[&:nth-child(odd)]:border-r"
            >
              {item}
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
