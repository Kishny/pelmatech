import * as React from 'react'

import { cn } from '@/lib/utils'

function Label({ className, ...props }: React.ComponentProps<'label'>) {
  return (
    <label
      className={cn(
        'text-xs font-medium tracking-[0.1em] uppercase text-muted-foreground',
        className,
      )}
      {...props}
    />
  )
}

export { Label }
