import * as React from 'react'
import { createFileRoute, Link } from '@tanstack/react-router'
import { ArrowUpRight } from 'lucide-react'

import hanaPhoto from '@/assets/hana.jpg'
import matteoPhoto from '@/assets/matteo.jpg'
import ariaPhoto from '@/assets/aria.jpg'
import kwamePhoto from '@/assets/kwame.jpg'
import helgaPhoto from '@/assets/helga.jpg'
// Dr. Noor Farouk is not part of the 5 named team members, but was
// invented to cover the "Women's Health" specialty. A real (AI-generated)
// portrait was supplied on 2026-08-13, replacing the earlier generic
// placeholder.
import noorPhoto from '@/assets/noor.jpg'
// Dr. Sofia Ramirez (Nutrition) and Dr. Amara Bello (Dermatology, skin-of-
// color specialist) requested 2026-08-14 to fill the two specialty filter
// chips ("Nutrition", "Dermatology") that previously had no matching
// doctor. AI-generated portraits (Gamma), saved 2026-08-14.
import sofiaPhoto from '@/assets/sofia.jpg'
import amaraPhoto from '@/assets/amara.jpg'
import { AnimatedHeading } from '@/components/AnimatedHeading'
import { AnimatedText } from '@/components/AnimatedText'
import { DoctorCard } from '@/components/DoctorCard'
import { Footer } from '@/components/Footer'
import { Header } from '@/components/Header'
import { useTranslation } from '@/i18n/LanguageContext'

export const Route = createFileRoute('/doctors')({ component: Doctors })

/**
 * Stable, UNTRANSLATED specialty keys — used only for filter matching
 * (button clicks, DOCTORS[i].specialtyKey comparison). Never rendered
 * directly. Display labels come from t.pages.doctors.specialties /
 * t.pages.doctors.doctors, matched by index below (2026-08-14: the
 * filter chips and doctor badges on this page were previously always
 * shown in English regardless of the selected language — fixed by
 * routing display text through the dictionary, the same pattern already
 * used by the homepage's Doctor Discovery section).
 */
const ALL_KEY = 'All'

const SPECIALTY_KEYS = [
  'General Practice',
  'Pediatrics',
  'Cardiology',
  'Neurology',
  'Therapy',
  'Nutrition',
  'Dermatology',
  "Women's Health",
]

// img + name + filter key stay fixed across languages; specialty label,
// availability, and experience are localized via t.pages.doctors.doctors
// (same order, matched by index).
const DOCTORS = [
  { img: hanaPhoto, name: 'Dr. Hana Sato', specialtyKey: 'Neurology' },
  { img: matteoPhoto, name: 'Dr. Matteo Dubois', specialtyKey: 'Therapy' },
  { img: ariaPhoto, name: 'Dr. Aria Vance', specialtyKey: 'Cardiology' },
  { img: kwamePhoto, name: 'Dr. Kwame Mbeki', specialtyKey: 'Pediatrics' },
  { img: helgaPhoto, name: 'Dr. Helga Brooks', specialtyKey: 'General Practice' },
  { img: noorPhoto, name: 'Dr. Noor Farouk', specialtyKey: "Women's Health" },
  { img: sofiaPhoto, name: 'Dr. Sofia Ramirez', specialtyKey: 'Nutrition' },
  { img: amaraPhoto, name: 'Dr. Amara Bello', specialtyKey: 'Dermatology' },
]

function Doctors() {
  const t = useTranslation()
  const [specialty, setSpecialty] = React.useState(ALL_KEY)

  const doctors = DOCTORS.map((doc, i) => ({
    ...doc,
    ...t.pages.doctors.doctors[i],
  }))

  const filtered =
    specialty === ALL_KEY ? doctors : doctors.filter((d) => d.specialtyKey === specialty)

  return (
    <div className="bg-background text-foreground">
      <Header variant="internal" />
      <main className="pt-40 pb-32 px-8 md:px-12">
        <AnimatedHeading as="h1" className="max-w-2xl text-5xl md:text-6xl font-medium leading-[1.05]">
          {t.pages.doctors.heading[0]}
          <br />
          {t.pages.doctors.heading[1]}
        </AnimatedHeading>
        <AnimatedText className="mt-6 max-w-xl text-base text-muted-foreground leading-relaxed">
          {t.pages.doctors.description}
        </AnimatedText>

        <div className="mt-10 flex flex-wrap gap-3">
          <button
            type="button"
            onClick={() => setSpecialty(ALL_KEY)}
            className={
              ALL_KEY === specialty
                ? 'rounded-full bg-foreground px-4 py-2 text-sm text-white transition'
                : 'rounded-full border border-border px-4 py-2 text-sm text-muted-foreground transition hover:bg-muted'
            }
          >
            {t.pages.doctors.allSpecialty}
          </button>
          {SPECIALTY_KEYS.map((key, i) => (
            <button
              key={key}
              type="button"
              onClick={() => setSpecialty(key)}
              className={
                key === specialty
                  ? 'rounded-full bg-foreground px-4 py-2 text-sm text-white transition'
                  : 'rounded-full border border-border px-4 py-2 text-sm text-muted-foreground transition hover:bg-muted'
              }
            >
              {t.pages.doctors.specialties[i]}
            </button>
          ))}
        </div>

        <div className="mt-16 grid grid-cols-2 gap-8 md:grid-cols-3">
          {filtered.map((doc, i) => (
            <div key={doc.name}>
              <DoctorCard {...doc} delay={i * 0.06} />
              <Link
                to="/appointments"
                className="mt-4 flex items-center gap-1 text-sm font-medium text-foreground"
              >
                {t.common.bookAppointmentAction}
                <ArrowUpRight className="h-4 w-4" />
              </Link>
            </div>
          ))}
        </div>
      </main>
      <Footer />
    </div>
  )
}
