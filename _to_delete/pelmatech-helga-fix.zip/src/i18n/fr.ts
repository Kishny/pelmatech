import type { Dictionary } from './en'

/**
 * French dictionary — default locale for the site. Same shape as
 * en.ts (enforced by the Dictionary type), including translations of
 * the originally "protected" hero/team/benefits copy, per the user's
 * explicit request (2026-08-13).
 */
export const fr: Dictionary = {
  meta: {
    title: 'Pelmatech — Votre compagnon de santé personnel',
    description:
      "Pelmatech est un compagnon de santé numérique personnel qui vous aide à comprendre, organiser, suivre et améliorer votre santé, tout en gardant accès à des professionnels de confiance.",
  },

  common: {
    tryForFree: 'Essayer gratuitement',
    scheduleDemo: 'Planifier une démo',
    getStarted: 'Commencer',
    bookAppointment: 'Prendre rendez-vous',
    bookAppointmentAction: 'Prendre rendez-vous',
    findDoctor: 'Trouver un médecin',
    howTelehealthWorks: 'Comment fonctionne la télésanté',
    buildHealthPlan: 'Créer mon plan de santé',
    exploreFitness: 'Explorer le fitness',
    addMedication: 'Ajouter un médicament',
    sendMessage: 'Envoyer le message',
    signIn: 'Se connecter',
    forgotPassword: 'Mot de passe oublié',
    createAccount: 'Créer un compte',
    back: 'Retour',
    continueLabel: 'Continuer',
    done: 'Terminé',
  },

  nav: {
    home: 'Accueil',
    artists: 'Artistes',
    releases: 'Sorties',
    contact: 'Contact',
    menu: 'Menu',
    closeMenu: 'Fermer le menu',
    platform: 'Plateforme',
    doctors: 'Médecins',
    pricing: 'Tarifs',
    about: 'À propos',
    faq: 'FAQ',
    login: 'Connexion',
    tagline: 'Votre compagnon de santé personnel',
  },

  hero: {
    titleLine1: 'Votre compagnon',
    titleLine2: 'de santé personnel',
    description:
      "Découvrez votre compagnon de santé en ligne personnel — une plateforme complète qui vous aide à suivre vos objectifs de forme, surveiller votre nutrition et planifier vos entraînements.",
    footerLeft: 'Applications de gestion pour entreprises',
    footerCenterCount: '01 / 04',
    footerCenterNext: 'Suivant',
    footerRight: 'Défiler pour découvrir',
  },

  team: {
    eyebrow1: 'Pelmatech',
    eyebrow2: 'Notre équipe',
    headingLine1: 'Faites connaissance avec l’équipe',
    headingLine2: 'qui fait tourner la machine',
    intro:
      "Sur notre plateforme, notre équipe dévouée travaille sans relâche pour améliorer notre présence en ligne et garantir la meilleure expérience possible à nos utilisateurs.",
    prevAria: 'Membre précédent',
    nextAria: 'Membre suivant',
    members: [
      { role: 'MÉDECIN GÉNÉRALE EN CHEF', name: 'Dr. Helga Brooks' },
      { role: 'PÉDIATRE', name: 'Dr. Kwame Mbeki' },
      { role: 'THÉRAPEUTE', name: 'Dr. Matteo Dubois' },
      { role: 'NEUROLOGUE', name: 'Dr. Hana Sato' },
      { role: 'CARDIOLOGUE', name: 'Dr. Aria Vance' },
    ],
  },

  benefits: {
    headingLine1: 'Découvrez les avantages',
    headingLine2: 'de notre plateforme',
    intro:
      "En choisissant une plateforme en ligne plutôt qu'hors ligne, les artistes peuvent toucher plus facilement un public mondial, se connecter avec des fans partout dans le monde et façonner l'avenir de la musique de manière dynamique.",
    cards: [
      {
        number: '01',
        title: 'Indisponibilité',
        body: "Nous comprenons qu'il peut arriver qu'un médecin ne soit pas disponible pour vous aider.",
      },
      {
        number: '02',
        title: 'Manque d’éthique',
        body: "Quand un médecin manque d'intégrité, il peut prescrire des médicaments à des fins promotionnelles plutôt que pour les besoins réels du patient, avec de graves conséquences sur la santé.",
      },
      {
        number: '03',
        title: "Liste d'attente",
        body: "Les patients peuvent connaître de longues attentes, parfois plusieurs heures, avant d'être pris en charge par le médecin.",
      },
    ],
  },

  featuresSection: {
    eyebrow1: 'Pelmatech',
    eyebrow2: 'Votre santé, connectée',
    headingLine1: 'Tout ce dont votre santé a besoin,',
    headingLine2: 'réuni au même endroit.',
    description:
      "Du suivi quotidien de votre bien-être aux rendez-vous et dossiers de santé, Pelmatech rassemble toutes les pièces de votre parcours de soin.",
    pillars: [
      { number: '01', title: 'Suivi de santé', body: 'Gardez chaque signe vital, habitude et tendance dans une vue claire.' },
      { number: '02', title: 'Rendez-vous', body: 'Réservez, replanifiez et rejoignez vos consultations sans aller-retours.' },
      { number: '03', title: 'Nutrition', body: 'Enregistrez vos repas et restez aligné avec vos objectifs personnels.' },
      { number: '04', title: 'Fitness', body: 'Planifiez vos entraînements et suivez votre activité au fil du temps.' },
    ],
  },

  doctorDiscovery: {
    headingLine1: 'Trouvez le bon professionnel',
    headingLine2: 'au bon moment.',
    description:
      "Parcourez les spécialités, vérifiez les disponibilités réelles et réservez avec un professionnel qui correspond à la prise en charge que vous recherchez.",
    specialties: [
      'Médecine générale',
      'Pédiatrie',
      'Cardiologie',
      'Neurologie',
      'Thérapie',
      'Nutrition',
      'Dermatologie',
      'Santé féminine',
    ],
    doctors: [
      { name: 'Dr. Helga Brooks', specialty: 'Médecine générale', availability: 'Prochaine dispo : aujourd’hui', experience: '20 ans' },
      { name: 'Dr. Hana Sato', specialty: 'Neurologue', availability: 'Prochaine dispo : aujourd’hui', experience: '12 ans' },
      { name: 'Dr. Matteo Dubois', specialty: 'Thérapeute', availability: 'Prochaine dispo : demain', experience: '8 ans' },
      { name: 'Dr. Aria Vance', specialty: 'Cardiologue', availability: 'Prochaine dispo : aujourd’hui', experience: '15 ans' },
      { name: 'Dr. Kwame Mbeki', specialty: 'Pédiatre', availability: 'Prochaine dispo : vendredi', experience: '10 ans' },
    ],
  },

  healthTracking: {
    headingLine1: 'Sachez comment vous allez.',
    headingLine2: 'Pas seulement comment vous vous sentez.',
    description:
      'Suivez les signaux de santé qui comptent pour vous et gardez une vision claire de votre progression dans le temps.',
    signals: ['Activité', 'Fréquence cardiaque', 'Sommeil', 'Poids', 'Hydratation', 'Tendances de bien-être'],
    metrics: [
      { value: '8 240', label: "Pas aujourd'hui" },
      { value: '72 bpm', label: 'Fréquence cardiaque au repos' },
      { value: '7h 42', label: 'Sommeil' },
      { value: '2,1 L', label: 'Hydratation' },
    ],
  },

  telehealth: {
    heading: "Des soins, quand vous en avez besoin.",
    description:
      'Connectez-vous à des professionnels de santé qualifiés sans perdre des heures en trajets, salles d’attente ou contraintes de planning.',
    points: [
      'Consultations vidéo sécurisées',
      'Professionnels vérifiés',
      'Horaires flexibles',
      'Messagerie de suivi',
    ],
  },

  personalPlan: {
    headingLine1: 'Un plan qui évolue',
    headingLine2: 'avec votre vie.',
    description:
      'Pelmatech réunit vos objectifs, vos routines, vos données de santé et l’accompagnement de professionnels dans un plan que vous pouvez vraiment suivre.',
    items: [
      'Objectifs quotidiens',
      'Cibles nutritionnelles',
      'Plan d’activité physique',
      'Calendrier de médication',
      'Rappels de rendez-vous',
      'Bilans de progression',
    ],
  },

  testimonials: {
    headingLine1: 'La santé se vit différemment',
    headingLine2: 'quand on ne la traverse pas seul.',
    prevAria: 'Témoignage précédent',
    nextAria: 'Témoignage suivant',
    items: [
      {
        quote:
          "J'ai enfin un seul endroit où comprendre mes rendez-vous, mes habitudes et mes objectifs, sans jongler entre cinq applications différentes.",
        name: 'Sofia, 30 ans',
        meta: 'Utilise Pelmatech pour le suivi de santé et la télésanté',
      },
      {
        quote:
          "Réserver une consultation le jour même était auparavant la partie la plus difficile pour obtenir de l'aide. Maintenant, ça prend deux minutes.",
        name: 'Marcus, 40 ans',
        meta: 'Utilise Pelmatech pour les rendez-vous et les médicaments',
      },
      {
        quote:
          "Mon équipe soignante et mon propre suivi communiquent enfin entre eux. Ça a changé le sérieux avec lequel j'aborde mes bilans.",
        name: 'Elena, 50 ans',
        meta: 'Utilise Pelmatech pour les soins familiaux',
      },
    ],
  },

  security: {
    headingLine1: 'Vos informations de santé',
    headingLine2: 'méritent une protection sérieuse.',
    description: 'Conçu avec des pratiques de confidentialité et de sécurité rigoureuses à chaque niveau de la plateforme.',
    points: [
      'Données chiffrées',
      'Authentification sécurisée',
      'Contrôles de confidentialité',
      'Permissions claires',
      'Communication professionnelle protégée',
    ],
  },

  appPreview: {
    headingLine1: 'Votre compagnon de santé,',
    headingLine2: 'où que vous soyez.',
    highlights: [
      'Tableau de bord quotidien',
      'Notifications de rendez-vous',
      'Rappels de médicaments',
      'Objectifs de santé',
      'Messagerie avec votre médecin',
    ],
  },

  faqHome: {
    headingLine1: 'Vos questions,',
    headingLine2: 'nos réponses claires.',
    description:
      "Pelmatech est conçu pour accompagner la gestion de votre santé au quotidien et faciliter la communication. Cela ne remplace pas les services d'urgence ni un diagnostic médical professionnel.",
    items: [
      {
        question: "Qu'est-ce que Pelmatech ?",
        answer:
          "Pelmatech est un compagnon de santé numérique personnel qui vous aide à comprendre, organiser, suivre et améliorer votre santé, tout en gardant accès à des professionnels de confiance.",
      },
      {
        question: 'Puis-je prendre rendez-vous en ligne ?',
        answer:
          'Oui. Choisissez une spécialité, sélectionnez un professionnel, choisissez un créneau et rejoignez votre rendez-vous directement depuis Pelmatech.',
      },
      {
        question: 'Pelmatech peut-il remplacer mon médecin ?',
        answer:
          "Non. Pelmatech est conçu pour accompagner la gestion de votre santé au quotidien et faciliter la communication. Cela ne remplace pas les services d'urgence ni un diagnostic médical professionnel.",
      },
      {
        question: 'Comment fonctionne le suivi de santé ?',
        answer:
          'Pelmatech rassemble les signaux de santé qui comptent pour vous — activité, fréquence cardiaque, sommeil, poids, hydratation et tendances de bien-être — dans une vue unique et claire.',
      },
      {
        question: 'Puis-je gérer mes médicaments ?',
        answer: 'Oui. Gardez vos médicaments organisés avec des horaires, des rappels, un suivi des renouvellements et un historique clair.',
      },
      {
        question: 'Comment mes informations sont-elles protégées ?',
        answer:
          'Pelmatech est conçu avec des pratiques rigoureuses de confidentialité et de sécurité, incluant le chiffrement des données, une authentification sécurisée et des contrôles de permissions clairs.',
      },
      {
        question: 'Puis-je utiliser Pelmatech pour les membres de ma famille ?',
        answer: 'Oui, les outils de soins familiaux vous permettent d’aider à coordonner la santé des personnes qui dépendent de vous.',
      },
    ],
  },

  finalCta: {
    headingLine1: 'Prenez mieux soin',
    headingLine2: 'de votre santé au quotidien.',
    description: 'Commencez à construire une vision plus claire et plus connectée de votre santé avec Pelmatech.',
  },

  footer: {
    columns: [
      { title: 'Plateforme', links: ['Suivi de santé', 'Rendez-vous', 'Nutrition', 'Fitness', 'Médicaments'] },
      { title: 'Entreprise', links: ['À propos', 'Notre équipe', 'Carrières', 'Contact'] },
      { title: 'Professionnels', links: ['Rejoindre Pelmatech', 'Portail médecin', 'Ressources'] },
      { title: 'Support', links: ["Centre d'aide", 'FAQ', 'Accessibilité'] },
      { title: 'Légal', links: ['Confidentialité', "Conditions d'utilisation", 'Cookies'] },
    ],
    copyright: '© Pelmatech',
    tagline: 'Votre compagnon de santé personnel',
  },

  mobileMenu: {
    brand: 'Pelmatech',
    tagline: 'Votre compagnon de santé personnel',
  },

  pages: {
    platform: {
      heading: ['Votre santé,', 'organisée autour de vous.'],
      description: "Chaque partie de la plateforme Pelmatech, réunie au même endroit — conçue pour fonctionner ensemble plutôt que dans des applications séparées.",
      capabilities: [
        { title: 'Tableau de bord', body: 'Une vue quotidienne unique de votre santé, vos rendez-vous et vos objectifs.' },
        { title: 'Suivi de santé', body: 'Activité, fréquence cardiaque, sommeil, poids, hydratation et tendances.' },
        { title: 'Rendez-vous', body: 'Réservez, replanifiez et rejoignez vos consultations sans aller-retours.' },
        { title: 'Nutrition', body: 'Enregistrement des repas, suivi des macros et objectifs personnels.' },
        { title: 'Fitness', body: 'Planification des entraînements, suivi d’activité et récupération.' },
        { title: 'Médication', body: 'Horaires, rappels, suivi des renouvellements et historique.' },
        { title: 'Dossiers de santé', body: 'Un historique clair et organisé de vos soins dans le temps.' },
        { title: 'Notifications', body: 'Des rappels qui vous gardent sur la bonne voie, sans excès.' },
      ],
    },
    doctors: {
      heading: ['Trouvez le bon professionnel', 'au bon moment.'],
      description: 'Filtrez par spécialité, vérifiez les disponibilités réelles et réservez directement avec un professionnel de confiance.',
      allSpecialty: 'Toutes',
    },
    pricing: {
      heading: ['Des formules adaptées', 'à la façon dont vous voulez être accompagné.'],
      description: 'Les tarifs sont en cours de finalisation — contactez-nous et notre équipe vous aidera à trouver la formule adaptée.',
      plans: [
        {
          name: 'Gratuit',
          price: 'Bientôt disponible',
          description: "Démarrez avec l'essentiel du suivi de santé au quotidien.",
          features: ['Suivi de santé de base', 'Prise de rendez-vous', "FAQ et centre d'aide"],
        },
        {
          name: 'Personnel',
          price: 'Nous contacter pour le tarif',
          description: 'La plateforme complète pour une personne, télésanté et plans inclus.',
          features: ['Tout ce qui est inclus dans Gratuit', 'Consultations en télésanté', 'Plan de santé personnel', 'Gestion des médicaments'],
        },
        {
          name: 'Famille',
          price: 'Nous contacter pour le tarif',
          description: 'Coordonnez la santé de toutes les personnes qui dépendent de vous.',
          features: ['Tout ce qui est inclus dans Personnel', 'Outils de soins familiaux', 'Calendrier de rendez-vous partagé', 'Support prioritaire'],
        },
      ],
    },
    about: {
      heading: ['Un compagnon de santé personnel,', 'construit sur la confiance.'],
      sections: [
        {
          title: 'Pourquoi Pelmatech existe',
          body: "La santé est souvent fragmentée entre applications, salles d'attente et paperasse. Pelmatech réunit les éléments de la gestion de santé au quotidien dans un espace connecté et humain.",
        },
        {
          title: 'Notre approche',
          body: "Nous associons un suivi de santé clair et honnête à un accès réel à des professionnels de confiance — jamais l'un sans l'autre.",
        },
        {
          title: 'Technologie et soin',
          body: 'Chaque fonctionnalité est conçue pour soutenir une vraie relation avec votre santé et votre équipe soignante, jamais pour la remplacer.',
        },
        {
          title: 'Nos valeurs',
          body: 'Le calme plutôt que le chaos, la clarté plutôt que le jargon, et une confiance gagnée par un design cohérent et soigné.',
        },
      ],
    },
    contact: {
      heading: 'Parlons-en.',
      description:
        'Questions sur Pelmatech, partenariats, ou envie de nous rejoindre en tant que professionnel — envoyez-nous un message et notre équipe reviendra vers vous.',
      fields: { name: 'Nom', email: 'Email', phone: 'Téléphone', reason: 'Motif du contact', message: 'Message' },
    },
    faq: {
      heading: ['Vos questions,', 'nos réponses claires.'],
      description:
        "Pelmatech est conçu pour accompagner la gestion de votre santé au quotidien et faciliter la communication. Cela ne remplace pas les services d'urgence ni un diagnostic médical professionnel.",
      categories: [
        {
          name: 'Compte',
          items: [
            { q: 'Comment créer un compte Pelmatech ?', a: "Sélectionnez Créer un compte depuis la page de connexion et suivez les quelques étapes : informations de base, objectifs de santé et préférences." },
            { q: 'Puis-je utiliser Pelmatech pour les membres de ma famille ?', a: 'Oui, les outils de soins familiaux vous permettent d’aider à coordonner la santé des personnes qui dépendent de vous.' },
          ],
        },
        {
          name: 'Rendez-vous',
          items: [
            { q: 'Puis-je prendre rendez-vous en ligne ?', a: 'Oui. Choisissez une spécialité, sélectionnez un professionnel, choisissez un créneau et rejoignez votre rendez-vous directement depuis Pelmatech.' },
            { q: 'Puis-je reprogrammer ou annuler ?', a: 'Oui, depuis la page Rendez-vous, vous pouvez gérer vos visites à venir, passées et annulées.' },
          ],
        },
        {
          name: 'Suivi de santé',
          items: [
            { q: 'Comment fonctionne le suivi de santé ?', a: "Pelmatech rassemble les signaux de santé qui comptent pour vous — activité, fréquence cardiaque, sommeil, poids, hydratation et tendances de bien-être — dans une vue unique et claire." },
          ],
        },
        {
          name: 'Médecins',
          items: [
            { q: 'Pelmatech peut-il remplacer mon médecin ?', a: "Non. Pelmatech est conçu pour accompagner la gestion de votre santé au quotidien et faciliter la communication. Cela ne remplace pas les services d'urgence ni un diagnostic médical professionnel." },
          ],
        },
        {
          name: 'Confidentialité',
          items: [
            { q: 'Comment mes informations sont-elles protégées ?', a: 'Pelmatech est conçu avec des pratiques rigoureuses de confidentialité et de sécurité, incluant le chiffrement des données, une authentification sécurisée et des contrôles de permissions clairs.' },
          ],
        },
        {
          name: 'Facturation',
          items: [
            { q: 'Combien coûte Pelmatech ?', a: 'Les tarifs sont en cours de finalisation. Consultez la page Tarifs ou contactez-nous pour les informations actuelles sur les formules.' },
          ],
        },
      ],
    },
    login: {
      heading: 'Content de vous revoir',
      fields: { email: 'Email', password: 'Mot de passe' },
    },
    signup: {
      steps: ['Informations de base', 'Objectifs de santé', 'Préférences', 'Configuration du compte'],
      goals: ['Bouger plus', 'Mieux manger', 'Mieux dormir', 'Gérer une condition', 'Suivre mes bilans de santé'],
      fields: { fullName: 'Nom complet', email: 'Email', reminders: 'Fréquence des rappels', remindersPlaceholder: 'ex. Quotidien', password: 'Créer un mot de passe' },
    },
    dashboard: {
      greeting: ['Bonjour, Alex.', 'Voici votre santé aujourd’hui.'],
      metrics: [
        { value: '86', label: 'Score du jour' },
        { value: '6 420', label: 'Activité (pas)' },
        { value: '7h 10', label: 'Sommeil' },
        { value: '1,6 L', label: 'Hydratation' },
      ],
      upcomingAppointments: 'Rendez-vous à venir',
      medicationReminders: 'Rappels de médicaments',
      nutritionGoal: 'Objectif nutritionnel',
      nutritionGoalValue: '1 840 / 2 100 kcal',
      todaysWorkout: 'Entraînement du jour',
      todaysWorkoutValue: '30 min — Mobilité',
      sampleAppointment: { doctor: 'Dr. Hana Sato', specialty: 'Neurologue', date: '15 août', time: '10h30', consultationType: 'Vidéo', status: 'À venir' },
      sampleMedications: [
        { name: 'Vitamine D — 1 comprimé', time: '08:00' },
        { name: 'Atorvastatine — 20mg', time: '21:00' },
      ],
    },
    appointments: {
      heading: ['Prenez rendez-vous', 'sans les allers-retours.'],
      steps: [
        { number: '01', label: 'Choisir une spécialité' },
        { number: '02', label: 'Sélectionner un professionnel' },
        { number: '03', label: 'Choisir un créneau' },
        { number: '04', label: 'Rejoindre votre rendez-vous' },
      ],
      tabs: { upcoming: 'À venir', past: 'Passés', cancelled: 'Annulés' },
      items: [
        { doctor: 'Dr. Hana Sato', specialty: 'Neurologue', date: '15 août', time: '10h30', consultationType: 'Vidéo', status: 'À venir' },
        { doctor: 'Dr. Matteo Dubois', specialty: 'Thérapeute', date: '22 août', time: '15h00', consultationType: 'En cabinet', status: 'À venir' },
        { doctor: 'Dr. Aria Vance', specialty: 'Cardiologue', date: '30 juil.', time: '9h00', consultationType: 'Vidéo', status: 'Passés' },
        { doctor: 'Dr. Kwame Mbeki', specialty: 'Pédiatre', date: '12 juil.', time: '13h15', consultationType: 'En cabinet', status: 'Annulés' },
      ],
    },
    health: {
      heading: 'Sachez comment vous allez.',
      description: 'Une vision claire de vos tendances de bien-être dans le temps — toujours basée sur les tokens de couleur, jamais sur la couleur comme seul signal.',
      metrics: [
        { value: '72 bpm', label: 'Fréquence cardiaque' },
        { value: '68 kg', label: 'Poids' },
        { value: '7h 42', label: 'Sommeil' },
        { value: '8 240', label: 'Activité (pas)' },
        { value: '2,1 L', label: 'Hydratation' },
        { value: '118 / 76', label: 'Tension artérielle' },
      ],
    },
    nutrition: {
      heading: ['La nutrition,', 'sans se compliquer la vie.'],
      description:
        "Comprenez ce que vous mangez, adoptez de meilleures habitudes et gardez votre nutrition alignée avec vos objectifs. Aucune allégation médicale — juste des informations plus claires.",
      features: ['Suivi des repas', 'Suivi des macronutriments', "Suivi de l'hydratation", 'Objectifs personnels', 'Analyses alimentaires', 'Accompagnement nutritionnel professionnel'],
      targets: [
        { value: '1 840 / 2 100', label: 'Calories (kcal)' },
        { value: '92 / 120 g', label: 'Protéines' },
        { value: '210 / 260 g', label: 'Glucides' },
        { value: '58 / 70 g', label: 'Lipides' },
        { value: '1,6 / 2,5 L', label: 'Eau' },
        { value: '3 enregistrés', label: "Repas aujourd'hui" },
      ],
    },
    fitness: {
      heading: ['Une activité physique adaptée', 'à la vie que vous menez vraiment.'],
      description: 'Planifiez vos entraînements, suivez votre activité et adaptez vos routines selon votre santé et votre emploi du temps.',
      features: ['Planification des entraînements', "Suivi de l'activité", 'Historique de progression', 'Objectifs personnels', 'Rappels de récupération'],
      metrics: [
        { value: '4 / 5', label: "Jours d'activité par semaine" },
        { value: '3 prévus', label: 'Entraînements' },
        { value: '+12 %', label: 'Progression (30j)' },
        { value: '2 jours', label: 'Rappel de récupération' },
      ],
    },
    medications: {
      heading: ['Une chose de moins', 'à oublier.'],
      description: 'Gardez vos médicaments organisés avec des horaires, des rappels, un suivi des renouvellements et un historique clair.',
      nextDoseLabel: 'Prochaine prise',
      items: [
        { name: 'Vitamine D', dosage: '1 comprimé', schedule: 'Quotidien', nextDose: '08:00', refill: '18 restants', prescriber: 'Dr. Helga Brooks' },
        { name: 'Atorvastatine', dosage: '20mg', schedule: 'Quotidien', nextDose: '21:00', refill: '6 restants · à renouveler bientôt', prescriber: 'Dr. Aria Vance' },
        { name: 'Sertraline', dosage: '50mg', schedule: 'Quotidien', nextDose: '08:00', refill: '24 restants', prescriber: 'Dr. Matteo Dubois' },
      ],
    },
    settings: {
      heading: 'Paramètres',
      sections: [
        { title: 'Profil', body: 'Nom, photo et informations personnelles.' },
        { title: 'Notifications', body: 'Rappels de rendez-vous, de médicaments et d’objectifs.' },
        { title: 'Confidentialité', body: 'Contrôlez ce qui est partagé, et avec qui.' },
        { title: 'Appareils connectés', body: 'Gérez vos objets connectés et applications liées.' },
        { title: 'Sécurité', body: 'Mot de passe, authentification à deux facteurs, sessions.' },
        { title: 'Supprimer le compte', body: 'Supprimez définitivement votre compte Pelmatech.' },
      ],
    },
    careers: {
      heading: 'Carrières chez Pelmatech',
      description:
        "Nous construisons une façon plus calme et plus connectée de gérer sa santé au quotidien. Si cette mission vous parle, nous serions ravis de vous entendre.",
      body: "Aucun poste n'est listé ici pour le moment. Passez par la page Contact et dites-nous comment vous aimeriez contribuer — nous lisons chaque message.",
    },
    join: {
      heading: 'Rejoignez Pelmatech en tant que professionnel',
      description:
        "Apportez votre pratique à une plateforme construite autour de soins calmes, clairs et connectés — et touchez des patients qui recherchent exactement cela.",
      body: "L'intégration des professionnels de santé est en cours de finalisation. Contactez-nous et notre équipe vous accompagnera dans les prochaines étapes.",
      cta: 'Nous contacter',
    },
    doctorPortal: {
      heading: 'Portail médecin',
      description: 'Gérez vos rendez-vous, les messages de vos patients et vos disponibilités au même endroit.',
      body: 'Le portail médecin fait partie des formules Personnel et Famille. Connectez-vous pour y accéder, ou contactez-nous si vous avez besoin d’un compte.',
      cta: 'Se connecter',
    },
    resources: {
      heading: 'Ressources',
      description: 'Des guides et informations pour tirer le meilleur parti de Pelmatech.',
      categories: ['Bien démarrer', 'Guides de suivi de santé', 'Conseils télésanté', 'Pour les professionnels'],
    },
    help: {
      heading: "Centre d'aide",
      description: 'Cherchez une réponse dans la FAQ, ou contactez-nous directement et nous vous aiderons personnellement.',
      faqCta: 'Voir la FAQ',
      contactCta: 'Contacter le support',
    },
    accessibility: {
      heading: 'Accessibilité',
      body: "Pelmatech est conçu avec une structure sémantique, une navigation au clavier, des états de focus visibles et des libellés accessibles partout sur la plateforme. Nous ne communiquons jamais un état de santé par la couleur seule. Si vous rencontrez un obstacle d'accessibilité, quel qu'il soit, dites-le-nous — nous voulons le corriger.",
    },
    privacy: {
      heading: 'Politique de confidentialité',
      body: "Cette page est un espace réservé. La politique de confidentialité complète de Pelmatech est en cours de finalisation par notre équipe juridique et sera publiée ici avant le lancement.",
    },
    terms: {
      heading: "Conditions d'utilisation",
      body: "Cette page est un espace réservé. Les conditions d'utilisation complètes de Pelmatech sont en cours de finalisation par notre équipe juridique et seront publiées ici avant le lancement.",
    },
    cookies: {
      heading: 'Politique de cookies',
      body: "Cette page est un espace réservé. La politique de cookies complète de Pelmatech est en cours de finalisation par notre équipe juridique et sera publiée ici avant le lancement.",
    },
  },
}
