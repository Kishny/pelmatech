import { Link } from '@tanstack/react-router'

import logoWhite from '@/assets/logo.svg'
import { useTranslation } from '@/i18n/LanguageContext'

/**
 * Real route for each footer link, positioned to match
 * `t.footer.columns[columnIndex].links[linkIndex]` exactly. Kept
 * separate from the translated labels (routes are locale-independent).
 * "Our Team" routes to /about, which renders the TeamCarousel section.
 */
const COLUMN_ROUTES = [
  ['/health', '/appointments', '/nutrition', '/fitness', '/medications'],
  ['/about', '/about', '/careers', '/contact'],
  ['/join', '/doctor-portal', '/resources'],
  ['/help', '/faq', '/accessibility'],
  ['/privacy', '/terms', '/cookies'],
] as const

export function Footer() {
  const t = useTranslation()

  return (
    <footer className="bg-foreground text-white px-8 py-20 md:px-12">
      <div className="grid grid-cols-2 gap-10 sm:grid-cols-3 md:grid-cols-6">
        <div className="col-span-2 sm:col-span-3 md:col-span-1">
          <Link to="/" aria-label="Pelmatech home">
            <img src={logoWhite} alt="Pelmatech" className="h-8 w-auto" />
          </Link>
        </div>
        {t.footer.columns.map((col, colIndex) => (
          <div key={col.title}>
            <div className="text-xs uppercase tracking-[0.2em] text-white/50">{col.title}</div>
            <ul className="mt-4 space-y-2">
              {col.links.map((link, linkIndex) => (
                <li key={link}>
                  <Link
                    to={COLUMN_ROUTES[colIndex][linkIndex]}
                    className="text-sm text-white/70 hover:text-white transition"
                  >
                    {link}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="mt-16 flex flex-col items-start justify-between gap-4 border-t border-white/10 pt-8 text-xs text-white/50 sm:flex-row sm:items-center">
        <span>{t.footer.copyright}</span>
        <span>{t.footer.tagline}</span>
      </div>
    </footer>
  )
}
