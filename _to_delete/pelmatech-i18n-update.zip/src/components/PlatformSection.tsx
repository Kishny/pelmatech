import blurDoctor from '@/assets/blur-doctor.png'
import happyDoctor from '@/assets/happy-doctor.png'
import youngDoctor from '@/assets/young-doctor.png'
import doctorConsultation from '@/assets/doctor-consultation.png'
import { AnimatedHeading } from '@/components/AnimatedHeading'
import { AnimatedText } from '@/components/AnimatedText'
import { DoctorCard } from '@/components/DoctorCard'
import { useTranslation } from '@/i18n/LanguageContext'

// Images stay local (not translated); name/specialty/availability/
// experience text comes from t.doctorDiscovery.doctors, matched by index.
const DOCTOR_IMAGES = [happyDoctor, youngDoctor, blurDoctor, doctorConsultation]

/**
 * Doctor Discovery (spec section 8) — bg-background, reuses the
 * TeamCarousel visual language via DoctorCard, as instructed.
 */
export function PlatformSection() {
  const t = useTranslation()
  const DOCTORS = t.doctorDiscovery.doctors.map((doc, i) => ({
    ...doc,
    img: DOCTOR_IMAGES[i],
  }))
  return (
    <section className="py-32 px-8 md:px-12 bg-background">
      <AnimatedHeading as="h2" className="text-5xl md:text-6xl font-medium leading-[1.05] max-w-3xl">
        {t.doctorDiscovery.headingLine1}
        <br />
        {t.doctorDiscovery.headingLine2}
      </AnimatedHeading>

      <AnimatedText className="mt-6 max-w-xl text-base text-muted-foreground leading-relaxed">
        {t.doctorDiscovery.description}
      </AnimatedText>

      <div className="mt-10 flex flex-wrap gap-3">
        {t.doctorDiscovery.specialties.map((s) => (
          <span
            key={s}
            className="rounded-full border border-border px-4 py-2 text-sm text-muted-foreground"
          >
            {s}
          </span>
        ))}
      </div>

      <div className="mt-16 grid grid-cols-2 gap-8 md:grid-cols-4">
        {DOCTORS.map((doc, i) => (
          <DoctorCard key={doc.name} {...doc} delay={i * 0.08} />
        ))}
      </div>
    </section>
  )
}
