export interface AppointmentCardProps {
  doctor: string
  specialty: string
  date: string
  time: string
  consultationType: string
  /** Translated, display-only status label (e.g. "Upcoming" / "À venir"). */
  status: string
  /**
   * Locale-independent status used purely for styling/filtering — never
   * shown to the user. Kept separate from `status` because the display
   * label is translated text and can't safely be compared/keyed against
   * across locales.
   */
  statusVariant: 'upcoming' | 'past' | 'cancelled'
}

const STATUS_STYLES: Record<AppointmentCardProps['statusVariant'], string> = {
  upcoming: 'bg-accent/10 text-accent',
  past: 'bg-muted text-muted-foreground',
  cancelled: 'bg-muted text-muted-foreground line-through',
}

export function AppointmentCard({ doctor, specialty, date, time, consultationType, status, statusVariant }: AppointmentCardProps) {
  return (
    <div className="flex flex-col gap-4 rounded-2xl border border-border bg-background p-6 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <div className="text-base font-medium text-foreground">{doctor}</div>
        <div className="text-sm text-muted-foreground">{specialty}</div>
      </div>
      <div className="flex flex-wrap items-center gap-6 text-sm text-muted-foreground">
        <span>{date}</span>
        <span>{time}</span>
        <span>{consultationType}</span>
        <span className={`rounded-full px-3 py-1 text-xs uppercase tracking-wide ${STATUS_STYLES[statusVariant]}`}>
          {status}
        </span>
      </div>
    </div>
  )
}
