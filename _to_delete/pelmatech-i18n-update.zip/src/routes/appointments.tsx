import * as React from 'react'
import { createFileRoute } from '@tanstack/react-router'

import { AnimatedHeading } from '@/components/AnimatedHeading'
import { AnimatedText } from '@/components/AnimatedText'
import { AppointmentCard } from '@/components/AppointmentCard'
import { Footer } from '@/components/Footer'
import { Header } from '@/components/Header'
import { Button } from '@/components/ui/button'
import { useTranslation } from '@/i18n/LanguageContext'

export const Route = createFileRoute('/appointments')({ component: Appointments })

const TABS = ['upcoming', 'past', 'cancelled'] as const

// Locale-independent status per dictionary item, matched by array index —
// the dictionary's `status` field is translated display text (e.g. "À
// venir"), so it can't be compared across locales; see AppointmentCard.tsx.
const STATUS_VARIANTS: Array<(typeof TABS)[number]> = ['upcoming', 'upcoming', 'past', 'cancelled']

function Appointments() {
  const t = useTranslation()
  const STEPS = t.pages.appointments.steps
  const APPOINTMENTS = t.pages.appointments.items.map((item, i) => ({
    ...item,
    statusVariant: STATUS_VARIANTS[i],
  }))
  const TAB_LABELS = t.pages.appointments.tabs
  const TAB_LABEL_MAP: Record<(typeof TABS)[number], string> = {
    upcoming: TAB_LABELS.upcoming,
    past: TAB_LABELS.past,
    cancelled: TAB_LABELS.cancelled,
  }

  const [tab, setTab] = React.useState<(typeof TABS)[number]>('upcoming')

  return (
    <div className="bg-background text-foreground">
      <Header variant="internal" />
      <main className="pt-40 pb-32 px-8 md:px-12">
        <AnimatedHeading as="h1" className="max-w-2xl text-5xl md:text-6xl font-medium leading-[1.05]">
          {t.pages.appointments.heading[0]}
          <br />
          {t.pages.appointments.heading[1]}
        </AnimatedHeading>

        <div className="mt-16 grid grid-cols-2 gap-8 border-t border-border pt-10 md:grid-cols-4">
          {STEPS.map((step, i) => (
            <div key={step.number}>
              <AnimatedText as="span" delay={i * 0.1} className="text-xs tracking-[0.2em] text-muted-foreground uppercase">
                {step.number}
              </AnimatedText>
              <AnimatedText delay={i * 0.1} className="mt-2 text-base font-medium text-foreground">
                {step.label}
              </AnimatedText>
            </div>
          ))}
        </div>

        <div className="mt-20 flex items-center justify-between">
          <div className="flex gap-2">
            {TABS.map((tabKey) => (
              <button
                key={tabKey}
                type="button"
                onClick={() => setTab(tabKey)}
                className={
                  tabKey === tab
                    ? 'rounded-full bg-foreground px-4 py-2 text-sm text-white transition'
                    : 'rounded-full border border-border px-4 py-2 text-sm text-muted-foreground transition hover:bg-muted'
                }
              >
                {TAB_LABEL_MAP[tabKey]}
              </button>
            ))}
          </div>
          <Button type="button">{t.common.bookAppointment}</Button>
        </div>

        <div className="mt-8 flex flex-col gap-4">
          {APPOINTMENTS.filter((a) => a.statusVariant === tab).map((a) => (
            <AppointmentCard key={`${a.doctor}-${a.date}`} {...a} />
          ))}
        </div>
      </main>
      <Footer />
    </div>
  )
}
