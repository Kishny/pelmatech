import { createFileRoute } from '@tanstack/react-router'
import {
  Activity,
  Bell,
  Calendar,
  Dumbbell,
  Apple,
  FileText,
  LayoutDashboard,
  Pill,
} from 'lucide-react'

import { AnimatedHeading } from '@/components/AnimatedHeading'
import { AnimatedText } from '@/components/AnimatedText'
import { Footer } from '@/components/Footer'
import { Header } from '@/components/Header'
import { useTranslation } from '@/i18n/LanguageContext'

export const Route = createFileRoute('/platform')({ component: Platform })

/**
 * Icons are presentational and kept locally, mapped by index onto the
 * translated `t.pages.platform.capabilities` entries (title/body).
 */
const CAPABILITY_ICONS = [
  LayoutDashboard,
  Activity,
  Calendar,
  Apple,
  Dumbbell,
  Pill,
  FileText,
  Bell,
]

function Platform() {
  const t = useTranslation()
  const capabilities = t.pages.platform.capabilities.map((cap, i) => ({
    ...cap,
    icon: CAPABILITY_ICONS[i],
  }))

  return (
    <div className="bg-background text-foreground">
      <Header variant="internal" />
      <main className="pt-40 pb-32 px-8 md:px-12">
        <AnimatedHeading as="h1" className="max-w-2xl text-5xl md:text-6xl font-medium leading-[1.05]">
          {t.pages.platform.heading[0]}
          <br />
          {t.pages.platform.heading[1]}
        </AnimatedHeading>
        <AnimatedText className="mt-6 max-w-xl text-base text-muted-foreground leading-relaxed">
          {t.pages.platform.description}
        </AnimatedText>

        <div className="mt-20 grid grid-cols-1 gap-px overflow-hidden rounded-2xl border border-border bg-border sm:grid-cols-2 lg:grid-cols-4">
          {capabilities.map((cap, i) => {
            const Icon = cap.icon
            return (
              <div key={cap.title} className="flex flex-col gap-4 bg-background p-8">
                <Icon className="h-6 w-6 text-accent" />
                <AnimatedHeading as="h2" delay={i * 0.05} className="text-lg font-medium">
                  {cap.title}
                </AnimatedHeading>
                <AnimatedText delay={i * 0.05} className="text-sm text-muted-foreground leading-relaxed">
                  {cap.body}
                </AnimatedText>
              </div>
            )
          })}
        </div>
      </main>
      <Footer />
    </div>
  )
}
