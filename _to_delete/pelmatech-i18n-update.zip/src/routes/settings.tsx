import { createFileRoute } from '@tanstack/react-router'
import {
  Bell,
  ChevronRight,
  Laptop,
  Lock,
  ShieldCheck,
  Trash2,
  User,
} from 'lucide-react'

import { AnimatedHeading } from '@/components/AnimatedHeading'
import { Footer } from '@/components/Footer'
import { Header } from '@/components/Header'
import { useTranslation } from '@/i18n/LanguageContext'

export const Route = createFileRoute('/settings')({ component: Settings })

/**
 * Icons and the "danger" (destructive-styling) flag aren't part of the
 * translation dictionary — they're presentation metadata local to this
 * route, zipped by index with the translated section copy below. The
 * "Delete account" row stays a plain, non-functional demo button (no
 * confirm dialog, no real handler) per spec.
 */
const SECTION_ICONS = [User, Bell, Lock, Laptop, ShieldCheck, Trash2]

function Settings() {
  const t = useTranslation()
  const page = t.pages.settings

  return (
    <div className="bg-background text-foreground">
      <Header variant="internal" />
      <main className="pt-40 pb-32 px-8 md:px-12">
        <AnimatedHeading as="h1" className="text-4xl md:text-5xl font-medium leading-[1.05]">
          {page.heading}
        </AnimatedHeading>

        <div className="mt-16 flex flex-col divide-y divide-border border-t border-b border-border">
          {page.sections.map((section, i) => {
            const Icon = SECTION_ICONS[i]
            const danger = i === page.sections.length - 1
            return (
              <button
                key={section.title}
                type="button"
                className="flex w-full items-center justify-between gap-4 py-6 text-left transition hover:bg-muted/40"
              >
                <div className="flex items-center gap-4">
                  <Icon className={danger ? 'h-5 w-5 text-red-500' : 'h-5 w-5 text-accent'} />
                  <div>
                    <div className={danger ? 'text-base font-medium text-red-600' : 'text-base font-medium'}>
                      {section.title}
                    </div>
                    <div className="text-sm text-muted-foreground">{section.body}</div>
                  </div>
                </div>
                <ChevronRight className="h-4 w-4 text-muted-foreground" />
              </button>
            )
          })}
        </div>
      </main>
      <Footer />
    </div>
  )
}
