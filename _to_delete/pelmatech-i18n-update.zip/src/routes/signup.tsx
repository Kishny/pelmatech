import * as React from 'react'
import { createFileRoute } from '@tanstack/react-router'
import { Check } from 'lucide-react'

import { AnimatedHeading } from '@/components/AnimatedHeading'
import { Header } from '@/components/Header'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useTranslation } from '@/i18n/LanguageContext'

export const Route = createFileRoute('/signup')({ component: Signup })

/**
 * Multi-step but visually simple, per spec. Intentionally does not
 * collect sensitive health data beyond generic, self-selected goals.
 */
function Signup() {
  const t = useTranslation()
  const STEPS = t.pages.signup.steps
  const GOALS = t.pages.signup.goals

  const [step, setStep] = React.useState(0)
  const [goals, setGoals] = React.useState<Array<string>>([])

  function toggleGoal(goal: string) {
    setGoals((g) => (g.includes(goal) ? g.filter((x) => x !== goal) : [...g, goal]))
  }

  return (
    <div className="bg-background text-foreground min-h-screen">
      <Header variant="internal" />
      <main className="flex min-h-screen items-center justify-center px-8 pt-24 pb-16 md:px-12">
        <div className="w-full max-w-md">
          <div className="mb-10 flex items-center gap-2">
            {STEPS.map((label, i) => (
              <div key={label} className="flex flex-1 items-center gap-2">
                <div
                  className={
                    i <= step
                      ? 'flex h-6 w-6 items-center justify-center rounded-full bg-foreground text-xs text-white'
                      : 'flex h-6 w-6 items-center justify-center rounded-full border border-border text-xs text-muted-foreground'
                  }
                >
                  {i < step ? <Check className="h-3 w-3" /> : i + 1}
                </div>
                {i < STEPS.length - 1 && (
                  <div className={i < step ? 'h-px flex-1 bg-foreground' : 'h-px flex-1 bg-border'} />
                )}
              </div>
            ))}
          </div>

          <AnimatedHeading as="h1" className="text-2xl font-medium">
            {STEPS[step]}
          </AnimatedHeading>

          <div className="mt-8 flex flex-col gap-6">
            {step === 0 && (
              <>
                <div className="flex flex-col gap-2">
                  <Label htmlFor="name">{t.pages.signup.fields.fullName}</Label>
                  <Input id="name" name="name" />
                </div>
                <div className="flex flex-col gap-2">
                  <Label htmlFor="email">{t.pages.signup.fields.email}</Label>
                  <Input id="email" name="email" type="email" />
                </div>
              </>
            )}

            {step === 1 && (
              <div className="flex flex-wrap gap-2">
                {GOALS.map((goal) => (
                  <button
                    key={goal}
                    type="button"
                    onClick={() => toggleGoal(goal)}
                    className={
                      goals.includes(goal)
                        ? 'rounded-full bg-foreground px-4 py-2 text-sm text-white transition'
                        : 'rounded-full border border-border px-4 py-2 text-sm text-muted-foreground transition hover:bg-muted'
                    }
                  >
                    {goal}
                  </button>
                ))}
              </div>
            )}

            {step === 2 && (
              <div className="flex flex-col gap-2">
                <Label htmlFor="reminders">{t.pages.signup.fields.reminders}</Label>
                <Input id="reminders" name="reminders" placeholder={t.pages.signup.fields.remindersPlaceholder} />
              </div>
            )}

            {step === 3 && (
              <div className="flex flex-col gap-2">
                <Label htmlFor="password">{t.pages.signup.fields.password}</Label>
                <Input id="password" name="password" type="password" />
              </div>
            )}
          </div>

          <div className="mt-10 flex items-center justify-between">
            <Button
              type="button"
              variant="ghost"
              onClick={() => setStep((s) => Math.max(0, s - 1))}
              disabled={step === 0}
            >
              {t.common.back}
            </Button>
            <Button
              type="button"
              onClick={() => setStep((s) => Math.min(STEPS.length - 1, s + 1))}
              disabled={step === STEPS.length - 1}
            >
              {step === STEPS.length - 1 ? t.common.done : t.common.continueLabel}
            </Button>
          </div>
        </div>
      </main>
    </div>
  )
}
