import { createFileRoute } from '@tanstack/react-router'
import { motion } from 'motion/react'
import type { ReactNode } from 'react'

import { Footer } from '@/components/Footer'
import { Header } from '@/components/Header'
import { HealthMetricCard } from '@/components/HealthMetricCard'
import { AppointmentCard } from '@/components/AppointmentCard'
import { useTranslation } from '@/i18n/LanguageContext'

export const Route = createFileRoute('/dashboard')({ component: Dashboard })

/** Dashboard cards use the calmer "authenticated page" motion values, not the dramatic marketing clipping. */
function DashboardCard({ children, delay = 0 }: { children: ReactNode; delay?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.55, delay, ease: [0.22, 1, 0.36, 1] }}
      className="rounded-2xl border border-border bg-background p-6"
    >
      {children}
    </motion.div>
  )
}

function Dashboard() {
  const t = useTranslation()
  const METRICS = t.pages.dashboard.metrics
  const { sampleAppointment, sampleMedications } = t.pages.dashboard

  return (
    <div className="bg-background text-foreground">
      <Header variant="internal" />
      <main className="pt-40 pb-32 px-8 md:px-12">
        <motion.h1
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
          className="text-3xl md:text-4xl font-medium leading-[1.05]"
        >
          {t.pages.dashboard.greeting[0]}
          <br />
          {t.pages.dashboard.greeting[1]}
        </motion.h1>

        <div className="mt-12 grid grid-cols-2 gap-4 md:grid-cols-4">
          {METRICS.map((m, i) => (
            <div key={m.label}>
              <HealthMetricCard {...m} delay={i * 0.05} />
            </div>
          ))}
        </div>

        <div className="mt-16 grid grid-cols-1 gap-8 md:grid-cols-2">
          <DashboardCard delay={0.1}>
            <h2 className="text-sm uppercase tracking-[0.2em] text-muted-foreground">
              {t.pages.dashboard.upcomingAppointments}
            </h2>
            <div className="mt-6">
              <AppointmentCard
                doctor={sampleAppointment.doctor}
                specialty={sampleAppointment.specialty}
                date={sampleAppointment.date}
                time={sampleAppointment.time}
                consultationType={sampleAppointment.consultationType}
                status={sampleAppointment.status}
                statusVariant="upcoming"
              />
            </div>
          </DashboardCard>

          <DashboardCard delay={0.15}>
            <h2 className="text-sm uppercase tracking-[0.2em] text-muted-foreground">
              {t.pages.dashboard.medicationReminders}
            </h2>
            <ul className="mt-6 space-y-3 text-sm">
              {sampleMedications.map((med, i) => (
                <li
                  key={med.name}
                  className={
                    i < sampleMedications.length - 1
                      ? 'flex items-center justify-between border-b border-border pb-3'
                      : 'flex items-center justify-between'
                  }
                >
                  <span>{med.name}</span>
                  <span className="text-muted-foreground">{med.time}</span>
                </li>
              ))}
            </ul>
          </DashboardCard>

          <DashboardCard delay={0.2}>
            <h2 className="text-sm uppercase tracking-[0.2em] text-muted-foreground">
              {t.pages.dashboard.nutritionGoal}
            </h2>
            <p className="mt-6 text-2xl font-medium">{t.pages.dashboard.nutritionGoalValue}</p>
          </DashboardCard>

          <DashboardCard delay={0.25}>
            <h2 className="text-sm uppercase tracking-[0.2em] text-muted-foreground">
              {t.pages.dashboard.todaysWorkout}
            </h2>
            <p className="mt-6 text-2xl font-medium">{t.pages.dashboard.todaysWorkoutValue}</p>
          </DashboardCard>
        </div>
      </main>
      <Footer />
    </div>
  )
}
