import * as React from 'react'
import { createFileRoute, Link } from '@tanstack/react-router'
import { ArrowUpRight } from 'lucide-react'

import hanaPhoto from '@/assets/hana.jpg'
import matteoPhoto from '@/assets/matteo.jpg'
import ariaPhoto from '@/assets/aria.jpg'
import kwamePhoto from '@/assets/kwame.jpg'
import helgaPhoto from '@/assets/helga.jpg'
// No real photo supplied for Dr. Noor Farouk (not part of the 5 named
// team members) — falls back to a generic placeholder per the "never
// silently substitute assets" rule; swap in a real photo if one is added.
import doctorConsultation from '@/assets/doctor-consultation.png'
import { AnimatedHeading } from '@/components/AnimatedHeading'
import { AnimatedText } from '@/components/AnimatedText'
import { DoctorCard } from '@/components/DoctorCard'
import { Footer } from '@/components/Footer'
import { Header } from '@/components/Header'
import { useTranslation } from '@/i18n/LanguageContext'

export const Route = createFileRoute('/doctors')({ component: Doctors })

/**
 * Specialty keys and doctor directory are sample domain data, not
 * covered by `t.pages.doctors` (which only holds heading/description/
 * allSpecialty) — they stay as internal filter keys. Only the "All"
 * chip has a translated label, applied at render time below.
 */
const ALL_KEY = 'All'

const SPECIALTIES = [
  ALL_KEY,
  'General Practice',
  'Pediatrics',
  'Cardiology',
  'Neurology',
  'Therapy',
  'Nutrition',
  'Dermatology',
  "Women's Health",
]

const DOCTORS = [
  { img: hanaPhoto, name: 'Dr. Hana Sato', specialty: 'Neurology', availability: 'Next available: Today', experience: '12 yrs' },
  { img: matteoPhoto, name: 'Dr. Matteo Dubois', specialty: 'Therapy', availability: 'Next available: Tomorrow', experience: '8 yrs' },
  { img: ariaPhoto, name: 'Dr. Aria Vance', specialty: 'Cardiology', availability: 'Next available: Today', experience: '15 yrs' },
  { img: kwamePhoto, name: 'Dr. Kwame Mbeki', specialty: 'Pediatrics', availability: 'Next available: Fri', experience: '10 yrs' },
  { img: helgaPhoto, name: 'Dr. Helga Brooks', specialty: 'General Practice', availability: 'Next available: Today', experience: '20 yrs' },
  { img: doctorConsultation, name: 'Dr. Noor Farouk', specialty: "Women's Health", availability: 'Next available: Mon', experience: '9 yrs' },
]

function Doctors() {
  const t = useTranslation()
  const [specialty, setSpecialty] = React.useState(ALL_KEY)

  const filtered =
    specialty === ALL_KEY ? DOCTORS : DOCTORS.filter((d) => d.specialty === specialty)

  return (
    <div className="bg-background text-foreground">
      <Header variant="internal" />
      <main className="pt-40 pb-32 px-8 md:px-12">
        <AnimatedHeading as="h1" className="max-w-2xl text-5xl md:text-6xl font-medium leading-[1.05]">
          {t.pages.doctors.heading[0]}
          <br />
          {t.pages.doctors.heading[1]}
        </AnimatedHeading>
        <AnimatedText className="mt-6 max-w-xl text-base text-muted-foreground leading-relaxed">
          {t.pages.doctors.description}
        </AnimatedText>

        <div className="mt-10 flex flex-wrap gap-3">
          {SPECIALTIES.map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => setSpecialty(s)}
              className={
                s === specialty
                  ? 'rounded-full bg-foreground px-4 py-2 text-sm text-white transition'
                  : 'rounded-full border border-border px-4 py-2 text-sm text-muted-foreground transition hover:bg-muted'
              }
            >
              {s === ALL_KEY ? t.pages.doctors.allSpecialty : s}
            </button>
          ))}
        </div>

        <div className="mt-16 grid grid-cols-2 gap-8 md:grid-cols-3">
          {filtered.map((doc, i) => (
            <div key={doc.name}>
              <DoctorCard {...doc} delay={i * 0.06} />
              <Link
                to="/appointments"
                className="mt-4 flex items-center gap-1 text-sm font-medium text-foreground"
              >
                {t.common.bookAppointmentAction}
                <ArrowUpRight className="h-4 w-4" />
              </Link>
            </div>
          ))}
        </div>
      </main>
      <Footer />
    </div>
  )
}
